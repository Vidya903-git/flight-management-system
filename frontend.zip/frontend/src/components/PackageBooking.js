// src/components/PackageBooking.js
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Container, Card, Button, Row, Col, Form } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const PackageBooking = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [packageData, setPackageData] = useState(null);
  const [formData, setFormData] = useState({
    travelers: 1,
    travelDate: "",
    passengerName: "",
    age: "",
    gender: "",
    mobile: "",
    email: "",
    idProofType: "Aadhar",
    idProofNumber: "",
  });
  const [paymentMethod, setPaymentMethod] = useState("");
  const [cardDetails, setCardDetails] = useState({
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
  });
  const [upiId, setUpiId] = useState("");
  const [walletSelected, setWalletSelected] = useState("");

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    if (!isLoggedIn) {
      navigate("/login");
      return;
    }

    // Get package data from location state
    if (location.state && location.state.packageData) {
      setPackageData(location.state.packageData);
      // Set minimum date as today
      const today = new Date().toISOString().split("T")[0];
      setFormData(prev => ({ ...prev, travelDate: today }));
    } else {
      // If no data, redirect to packages page
      navigate("/packages");
    }
  }, [location, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
    setCardDetails({ cardNumber: "", cardName: "", expiryDate: "", cvv: "" });
    setUpiId("");
    setWalletSelected("");
  };

  const handleCardChange = (e) => {
    const { name, value } = e.target;
    setCardDetails({ ...cardDetails, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate form
    if (!formData.travelDate || !formData.passengerName || !formData.age || 
        !formData.gender || !formData.mobile || !formData.email || !formData.idProofNumber) {
      alert("Please fill in all required fields!");
      return;
    }

    if (!paymentMethod) {
      alert("Please select a payment method!");
      return;
    }

    // Validate payment details
    if (paymentMethod === "card") {
      if (!cardDetails.cardNumber || !cardDetails.cardName || !cardDetails.expiryDate || !cardDetails.cvv) {
        alert("Please fill in all card details!");
        return;
      }
    } else if (paymentMethod === "upi") {
      if (!upiId || !/^[\w.-]+@[\w]+$/.test(upiId)) {
        alert("Please enter a valid UPI ID!");
        return;
      }
    } else if (paymentMethod === "wallet") {
      if (!walletSelected) {
        alert("Please select a wallet!");
        return;
      }
    }

    // Calculate total price
    const basePrice = packageData.price;
    const totalPrice = basePrice * formData.travelers;
    const taxes = Math.floor(totalPrice * 0.18);
    const serviceCharge = Math.floor(totalPrice * 0.02);
    const finalTotal = totalPrice + taxes + serviceCharge;

    // Create booking confirmation
    const bookingConfirmation = {
      packageData,
      formData,
      paymentMethod,
      paymentDetails: paymentMethod === "card" ? cardDetails : paymentMethod === "upi" ? { upiId } : { wallet: walletSelected },
      bookingId: `PKG${Date.now()}`,
      bookingDate: new Date().toISOString(),
      pricing: {
        basePrice,
        travelers: formData.travelers,
        totalPrice,
        taxes,
        serviceCharge,
        finalTotal,
      },
    };

    // Store booking confirmation
    localStorage.setItem("lastPackageBooking", JSON.stringify(bookingConfirmation));

    // Navigate to booking confirmation page
    navigate("/package-booking-confirmation", {
      state: bookingConfirmation,
    });
  };

  const styles = {
    container: {
      padding: "40px 20px",
      backgroundColor: "#f8f9fa",
      minHeight: "100vh",
    },
    loadingContainer: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundColor: "#f8f9fa",
    },
    title: {
      fontSize: "2rem",
      fontWeight: "600",
      color: "#222",
      marginBottom: "30px",
      textAlign: "center",
    },
    card: {
      border: "none",
      borderRadius: "12px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
      marginBottom: "20px",
    },
    cardHeader: {
      backgroundColor: "#0071eb",
      color: "#fff",
      padding: "15px 20px",
      borderRadius: "12px 12px 0 0",
      fontSize: "1.2rem",
      fontWeight: "600",
    },
    cardBody: {
      padding: "30px",
    },
    sectionTitle: {
      fontSize: "1.3rem",
      fontWeight: "600",
      color: "#333",
      marginBottom: "15px",
      borderBottom: "2px solid #e9ecef",
      paddingBottom: "10px",
    },
    input: {
      width: "100%",
      padding: "10px 15px",
      borderRadius: "8px",
      border: "1px solid #ccc",
      fontSize: "1rem",
      marginTop: "8px",
    },
    select: {
      width: "100%",
      padding: "10px 15px",
      borderRadius: "8px",
      border: "1px solid #ccc",
      fontSize: "1rem",
      backgroundColor: "#fff",
      marginTop: "8px",
    },
    paymentMethodCard: {
      border: "2px solid #e9ecef",
      borderRadius: "8px",
      padding: "15px",
      marginBottom: "15px",
      cursor: "pointer",
      transition: "all 0.3s",
    },
    paymentMethodCardActive: {
      border: "2px solid #0071eb",
      backgroundColor: "#e7f0ff",
    },
    paymentIcon: {
      fontSize: "1.5rem",
      marginRight: "10px",
    },
    submitButton: {
      backgroundColor: "#28a745",
      border: "none",
      padding: "15px 40px",
      borderRadius: "8px",
      color: "white",
      fontWeight: "600",
      fontSize: "1.1rem",
      cursor: "pointer",
      width: "100%",
      marginTop: "20px",
    },
    priceSummary: {
      backgroundColor: "#f8f9fa",
      padding: "20px",
      borderRadius: "8px",
      marginTop: "20px",
    },
    infoRow: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 0",
      borderBottom: "1px solid #f0f0f0",
    },
    infoLabel: {
      fontWeight: "500",
      color: "#666",
    },
    infoValue: {
      fontWeight: "600",
      color: "#222",
    },
    totalPrice: {
      fontSize: "1.5rem",
      fontWeight: "700",
      color: "#28a745",
      marginTop: "10px",
    },
    packageImage: {
      width: "100%",
      height: "200px",
      objectFit: "cover",
      borderRadius: "8px",
      marginBottom: "15px",
    },
  };

  if (!packageData) {
    return (
      <div style={styles.loadingContainer}>
        <p>Loading booking details...</p>
      </div>
    );
  }

  const basePrice = packageData.price;
  const totalPrice = basePrice * formData.travelers;
  const taxes = Math.floor(totalPrice * 0.18);
  const serviceCharge = Math.floor(totalPrice * 0.02);
  const finalTotal = totalPrice + taxes + serviceCharge;

  return (
    <div style={styles.container}>
      <Container>
        <h2 style={styles.title}>Complete Your Package Booking</h2>

        <Row>
          {/* Left Column: Package & Booking Details */}
          <Col md={8}>
            {/* Package Summary */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>📦 Package Details</div>
              <div style={styles.cardBody}>
                <img src={packageData.image} alt={packageData.name} style={styles.packageImage} />
                <h4>{packageData.name}</h4>
                <p style={{ color: "#666", marginBottom: "10px" }}>📍 {packageData.location}</p>
                <p style={{ color: "#666" }}>⏱️ {packageData.duration}</p>
              </div>
            </Card>

            {/* Traveler Information */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>👤 Traveler Information</div>
              <div style={styles.cardBody}>
                <Form>
                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Number of Travelers *</Form.Label>
                        <Form.Select
                          name="travelers"
                          value={formData.travelers}
                          onChange={handleChange}
                          style={styles.select}
                        >
                          {[1, 2, 3, 4, 5, 6].map((num) => (
                            <option key={num} value={num}>
                              {num} {num > 1 ? "Travelers" : "Traveler"}
                            </option>
                          ))}
                        </Form.Select>
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Travel Date *</Form.Label>
                        <Form.Control
                          type="date"
                          name="travelDate"
                          value={formData.travelDate}
                          onChange={handleChange}
                          min={new Date().toISOString().split("T")[0]}
                          style={styles.input}
                        />
                      </Form.Group>
                    </Col>
                  </Row>

                  <div style={styles.sectionTitle}>Primary Traveler Details</div>

                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Full Name *</Form.Label>
                        <Form.Control
                          type="text"
                          name="passengerName"
                          value={formData.passengerName}
                          onChange={handleChange}
                          placeholder="Enter full name"
                          style={styles.input}
                        />
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group className="mb-3">
                        <Form.Label>Age *</Form.Label>
                        <Form.Control
                          type="number"
                          name="age"
                          value={formData.age}
                          onChange={handleChange}
                          placeholder="Age"
                          min="1"
                          max="120"
                          style={styles.input}
                        />
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group className="mb-3">
                        <Form.Label>Gender *</Form.Label>
                        <Form.Select
                          name="gender"
                          value={formData.gender}
                          onChange={handleChange}
                          style={styles.select}
                        >
                          <option value="">Select</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Mobile Number *</Form.Label>
                        <Form.Control
                          type="tel"
                          name="mobile"
                          value={formData.mobile}
                          onChange={handleChange}
                          placeholder="10-digit mobile number"
                          maxLength="10"
                          style={styles.input}
                        />
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Email Address *</Form.Label>
                        <Form.Control
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="your.email@example.com"
                          style={styles.input}
                        />
                      </Form.Group>
                    </Col>
                  </Row>

                  <div style={styles.sectionTitle}>ID Proof</div>

                  <Row>
                    <Col md={4}>
                      <Form.Group className="mb-3">
                        <Form.Label>ID Proof Type *</Form.Label>
                        <Form.Select
                          name="idProofType"
                          value={formData.idProofType}
                          onChange={handleChange}
                          style={styles.select}
                        >
                          <option value="Aadhar">Aadhar Card</option>
                          <option value="Passport">Passport</option>
                          <option value="PAN">PAN Card</option>
                          <option value="Driving License">Driving License</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                    <Col md={8}>
                      <Form.Group className="mb-3">
                        <Form.Label>ID Proof Number *</Form.Label>
                        <Form.Control
                          type="text"
                          name="idProofNumber"
                          value={formData.idProofNumber}
                          onChange={handleChange}
                          placeholder="Enter ID proof number"
                          style={styles.input}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                </Form>
              </div>
            </Card>

            {/* Payment Methods */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>💳 Payment</div>
              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Select Payment Method</div>

                {/* Credit/Debit Card */}
                <div
                  style={{
                    ...styles.paymentMethodCard,
                    ...(paymentMethod === "card" ? styles.paymentMethodCardActive : {}),
                  }}
                  onClick={() => handlePaymentMethodChange("card")}
                >
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <span style={styles.paymentIcon}>💳</span>
                    <div>
                      <div style={{ fontWeight: "600", marginBottom: "5px" }}>
                        Credit / Debit Card
                      </div>
                      <small style={{ color: "#666" }}>
                        Visa, Mastercard, RuPay accepted
                      </small>
                    </div>
                  </div>
                </div>

                {paymentMethod === "card" && (
                  <div style={{ marginTop: "20px", padding: "20px", backgroundColor: "#f8f9fa", borderRadius: "8px" }}>
                    <Form.Group className="mb-3">
                      <Form.Label>Card Number</Form.Label>
                      <Form.Control
                        type="text"
                        name="cardNumber"
                        value={cardDetails.cardNumber}
                        onChange={handleCardChange}
                        placeholder="1234 5678 9012 3456"
                        maxLength="19"
                        style={styles.input}
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Cardholder Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="cardName"
                        value={cardDetails.cardName}
                        onChange={handleCardChange}
                        placeholder="Name on card"
                        style={styles.input}
                      />
                    </Form.Group>
                    <Row>
                      <Col md={6}>
                        <Form.Group className="mb-3">
                          <Form.Label>Expiry Date</Form.Label>
                          <Form.Control
                            type="text"
                            name="expiryDate"
                            value={cardDetails.expiryDate}
                            onChange={handleCardChange}
                            placeholder="MM/YY"
                            maxLength="5"
                            style={styles.input}
                          />
                        </Form.Group>
                      </Col>
                      <Col md={6}>
                        <Form.Group className="mb-3">
                          <Form.Label>CVV</Form.Label>
                          <Form.Control
                            type="text"
                            name="cvv"
                            value={cardDetails.cvv}
                            onChange={handleCardChange}
                            placeholder="123"
                            maxLength="3"
                            style={styles.input}
                          />
                        </Form.Group>
                      </Col>
                    </Row>
                  </div>
                )}

                {/* UPI */}
                <div
                  style={{
                    ...styles.paymentMethodCard,
                    ...(paymentMethod === "upi" ? styles.paymentMethodCardActive : {}),
                  }}
                  onClick={() => handlePaymentMethodChange("upi")}
                >
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <span style={styles.paymentIcon}>📱</span>
                    <div>
                      <div style={{ fontWeight: "600", marginBottom: "5px" }}>UPI</div>
                      <small style={{ color: "#666" }}>Paytm, Google Pay, PhonePe, BHIM</small>
                    </div>
                  </div>
                </div>

                {paymentMethod === "upi" && (
                  <div style={{ marginTop: "20px", padding: "20px", backgroundColor: "#f8f9fa", borderRadius: "8px" }}>
                    <Form.Group className="mb-3">
                      <Form.Label>UPI ID</Form.Label>
                      <Form.Control
                        type="text"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        placeholder="yourname@paytm"
                        style={styles.input}
                      />
                    </Form.Group>
                  </div>
                )}

                {/* Wallets */}
                <div
                  style={{
                    ...styles.paymentMethodCard,
                    ...(paymentMethod === "wallet" ? styles.paymentMethodCardActive : {}),
                  }}
                  onClick={() => handlePaymentMethodChange("wallet")}
                >
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <span style={styles.paymentIcon}>👛</span>
                    <div>
                      <div style={{ fontWeight: "600", marginBottom: "5px" }}>Digital Wallet</div>
                      <small style={{ color: "#666" }}>Paytm, PhonePe, Amazon Pay</small>
                    </div>
                  </div>
                </div>

                {paymentMethod === "wallet" && (
                  <div style={{ marginTop: "20px", padding: "20px", backgroundColor: "#f8f9fa", borderRadius: "8px" }}>
                    <Form.Group className="mb-3">
                      <Form.Label>Select Wallet</Form.Label>
                      <Form.Select
                        value={walletSelected}
                        onChange={(e) => setWalletSelected(e.target.value)}
                        style={styles.select}
                      >
                        <option value="">Choose a wallet</option>
                        <option value="paytm">Paytm</option>
                        <option value="phonepe">PhonePe</option>
                        <option value="amazonpay">Amazon Pay</option>
                      </Form.Select>
                    </Form.Group>
                  </div>
                )}
              </div>
            </Card>
          </Col>

          {/* Right Column: Price Summary */}
          <Col md={4}>
            <Card style={styles.card}>
              <div style={styles.cardHeader}>💰 Price Summary</div>
              <div style={styles.cardBody}>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Base Price ({formData.travelers} {formData.travelers > 1 ? "travelers" : "traveler"}):</span>
                  <span style={styles.infoValue}>₹{totalPrice.toLocaleString()}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Taxes & Fees:</span>
                  <span style={styles.infoValue}>₹{taxes.toLocaleString()}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Service Charge:</span>
                  <span style={styles.infoValue}>₹{serviceCharge.toLocaleString()}</span>
                </div>
                <div style={styles.priceSummary}>
                  <div style={styles.infoRow}>
                    <span style={styles.infoLabel}>Total Amount:</span>
                    <span style={styles.totalPrice}>₹{finalTotal.toLocaleString()}</span>
                  </div>
                </div>
                <Button
                  type="button"
                  onClick={handleSubmit}
                  style={styles.submitButton}
                >
                  Confirm & Pay
                </Button>
                <p style={{ fontSize: "0.85rem", color: "#666", marginTop: "15px", textAlign: "center" }}>
                  By proceeding, you agree to our Terms & Conditions
                </p>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default PackageBooking;

