// src/components/PackageDetails.js
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Container, Row, Col, Card, Button, Badge } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import AuthModal from "./AuthModal"; // ✅ adjust the path if needed


// Sample detailed package data (in a real app, this would come from an API)
const packageDetails = {
    1: {
      id: 1,
      name: "Paris Romance",
      location: "Paris, France",
      price: 65000,
      duration: "5 Days / 4 Nights",
      rating: 4.8,
      reviews: 1247,
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200&h=600&fit=crop",
      images: [
        "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=800&h=600&fit=crop",
      ],
      features: ["Eiffel Tower Visit", "Louvre Museum", "River Cruise", "Notre-Dame Cathedral", "Champs-Élysées Walk"],
      description: "Experience the romance of Paris with this carefully curated package. Visit iconic landmarks, enjoy French cuisine, and immerse yourself in the city's rich culture and history.",
      itinerary: [
        { day: 1, title: "Arrival & City Tour", description: "Arrive in Paris, hotel check-in, and evening city tour" },
        { day: 2, title: "Eiffel Tower & Louvre", description: "Visit the iconic Eiffel Tower and explore the world-famous Louvre Museum" },
        { day: 3, title: "Seine River Cruise", description: "Enjoy a scenic cruise along the Seine River and visit Notre-Dame" },
        { day: 4, title: "Champs-Élysées & Shopping", description: "Stroll down Champs-Élysées and enjoy shopping in Paris" },
        { day: 5, title: "Departure", description: "Breakfast and departure" },
      ],
      inclusions: [
        "4 nights accommodation in 4-star hotel",
        "Daily breakfast",
        "Airport transfers",
        "All entry tickets to mentioned attractions",
        "Professional tour guide",
        "Travel insurance",
      ],
      exclusions: [
        "International flights",
        "Lunch and dinner (except breakfast)",
        "Personal expenses",
        "Visa fees",
      ],
    },
    2: {
      id: 2,
      name: "Tokyo Discovery",
      location: "Tokyo, Japan",
      price: 75000,
      duration: "6 Days / 5 Nights",
      rating: 4.9,
      reviews: 892,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=1200&h=600&fit=crop",
      images: [
        "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop",
      ],
      features: ["Shibuya Crossing", "Temples Tour", "Sushi Experience", "Tokyo Skytree", "Traditional Tea Ceremony"],
      description: "Discover the perfect blend of traditional and modern Japan in Tokyo. From ancient temples to futuristic districts, experience the best of Japanese culture.",
      itinerary: [
        { day: 1, title: "Arrival & Shibuya", description: "Arrive in Tokyo, hotel check-in, and visit Shibuya Crossing" },
        { day: 2, title: "Temples & Shrines", description: "Visit Senso-ji Temple and Meiji Shrine" },
        { day: 3, title: "Tokyo Skytree", description: "Visit Tokyo Skytree and explore Asakusa district" },
        { day: 4, title: "Sushi & Culture", description: "Sushi making class and traditional tea ceremony" },
        { day: 5, title: "Harajuku & Shopping", description: "Explore Harajuku district and shopping in Ginza" },
        { day: 6, title: "Departure", description: "Breakfast and departure" },
      ],
      inclusions: [
        "5 nights accommodation in 4-star hotel",
        "Daily breakfast",
        "Airport transfers",
        "All entry tickets",
        "Sushi making class",
        "Travel insurance",
      ],
      exclusions: [
        "International flights",
        "Lunch and dinner",
        "Personal expenses",
        "Visa fees",
      ],
    },
    3: {
      id: 3,
      name: "Santorini Sunset",
      location: "Santorini, Greece",
      price: 95000,
      duration: "4 Days / 3 Nights",
      rating: 4.7,
      reviews: 634,
      image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=1200&h=600&fit=crop",
      images: [
        "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=800&h=600&fit=crop",
      ],
      features: ["Sunset Views", "Wine Tasting", "Beach Hopping", "Oia Village", "Volcano Tour"],
      description: "Experience the breathtaking sunsets and stunning views of Santorini. Stay in beautiful cliffside hotels and explore the island's unique beauty.",
      itinerary: [
        { day: 1, title: "Arrival & Oia", description: "Arrive in Santorini, hotel check-in, and explore Oia village" },
        { day: 2, title: "Wine Tasting & Beach", description: "Wine tasting tour and visit Red Beach" },
        { day: 3, title: "Volcano Tour", description: "Boat tour to the volcano and hot springs" },
        { day: 4, title: "Departure", description: "Breakfast and departure" },
      ],
      inclusions: [
        "3 nights accommodation in cliffside hotel",
        "Daily breakfast",
        "Airport transfers",
        "Wine tasting tour",
        "Volcano boat tour",
        "Travel insurance",
      ],
      exclusions: [
        "International flights",
        "Lunch and dinner",
        "Personal expenses",
        "Visa fees",
      ],
    },
    4: {
      id: 4,
      name: "Maldives Paradise",
      location: "Maldives",
      price: 115000,
      duration: "6 Days / 5 Nights",
      rating: 4.9,
      reviews: 1123,
      image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200&h=600&fit=crop",
      images: [
        "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=600&fit=crop",
      ],
      features: ["Water Villa", "Snorkeling", "Spa Sessions", "Sunset Cruise", "Underwater Restaurant"],
      description: "Escape to paradise in the Maldives. Stay in luxurious water villas, enjoy world-class diving, and relax at premium spa resorts.",
      itinerary: [
        { day: 1, title: "Arrival & Resort Check-in", description: "Arrive in Maldives, speedboat transfer to resort, and check-in to water villa" },
        { day: 2, title: "Snorkeling & Water Sports", description: "Snorkeling adventure and water sports activities" },
        { day: 3, title: "Spa & Relaxation", description: "Luxury spa treatments and beach relaxation" },
        { day: 4, title: "Sunset Cruise", description: "Evening sunset cruise with dinner" },
        { day: 5, title: "Underwater Experience", description: "Visit underwater restaurant and enjoy marine life" },
        { day: 6, title: "Departure", description: "Breakfast and departure" },
      ],
      inclusions: [
        "5 nights in water villa",
        "All meals included",
        "Airport transfers",
        "Snorkeling equipment",
        "Spa session",
        "Travel insurance",
      ],
      exclusions: [
        "International flights",
        "Premium alcohol",
        "Personal expenses",
        "Visa fees",
      ],
    },
    5: {
      id: 5,
      name: "New York City",
      location: "New York, USA",
      price: 125000,
      duration: "7 Days / 6 Nights",
      rating: 4.6,
      reviews: 856,
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=1200&h=600&fit=crop",
      images: [
        "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=800&h=600&fit=crop",
      ],
      features: ["Statue of Liberty", "Broadway Show", "Central Park", "Times Square", "Empire State Building"],
      description: "Experience the Big Apple with this comprehensive New York City package. Visit iconic landmarks, enjoy Broadway shows, and explore the city that never sleeps.",
      itinerary: [
        { day: 1, title: "Arrival & Times Square", description: "Arrive in NYC, hotel check-in, and explore Times Square" },
        { day: 2, title: "Statue of Liberty & Ellis Island", description: "Visit Statue of Liberty and Ellis Island" },
        { day: 3, title: "Central Park & Museums", description: "Explore Central Park and visit museums" },
        { day: 4, title: "Broadway Show", description: "Evening Broadway show experience" },
        { day: 5, title: "Empire State & Shopping", description: "Visit Empire State Building and shopping" },
        { day: 6, title: "Brooklyn Bridge & DUMBO", description: "Walk across Brooklyn Bridge and explore DUMBO" },
        { day: 7, title: "Departure", description: "Breakfast and departure" },
      ],
      inclusions: [
        "6 nights accommodation in Manhattan",
        "Daily breakfast",
        "Airport transfers",
        "Broadway show ticket",
        "All attraction entry tickets",
        "Travel insurance",
      ],
      exclusions: [
        "International flights",
        "Lunch and dinner",
        "Personal expenses",
        "Visa fees",
      ],
    },
};

// Helper function to create basic package data for packages without full details
const createBasicPackageData = (packageId) => {
    const basicPackages = {
      6: { name: "Singapore Explorer", location: "Singapore", price: 45000, duration: "4 Days / 3 Nights", rating: 4.8, reviews: 567 },
      7: { name: "Thailand Adventure", location: "Bangkok & Phuket", price: 55000, duration: "6 Days / 5 Nights", rating: 4.7, reviews: 789 },
      8: { name: "London Heritage", location: "London, UK", price: 85000, duration: "5 Days / 4 Nights", rating: 4.8, reviews: 654 },
      9: { name: "Iceland Northern Lights", location: "Reykjavik, Iceland", price: 145000, duration: "6 Days / 5 Nights", rating: 4.9, reviews: 432 },
    };
    
    const basic = basicPackages[packageId];
    if (!basic) return null;
    
    return {
      ...basic,
      id: packageId,
      image: `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&h=600&fit=crop`,
      images: [
        `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop`,
        `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop`,
        `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop`,
      ],
      features: ["City Tour", "Cultural Experience", "Local Cuisine"],
      description: `Explore ${basic.location} with this amazing travel package. Experience the best of what this destination has to offer.`,
      itinerary: [
        { day: 1, title: "Arrival", description: "Arrive and check-in to hotel" },
        { day: 2, title: "City Tour", description: "Explore the city's main attractions" },
        { day: 3, title: "Cultural Experience", description: "Immerse in local culture and traditions" },
        { day: 4, title: "Departure", description: "Breakfast and departure" },
      ],
      inclusions: [
        "Hotel accommodation",
        "Daily breakfast",
        "Airport transfers",
        "City tour",
        "Travel insurance",
      ],
      exclusions: [
        "International flights",
        "Lunch and dinner",
        "Personal expenses",
        "Visa fees",
      ],
    };
};

const PackageDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [packageData, setPackageData] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [pendingPackage, setPendingPackage] = useState(null);


  useEffect(() => {
    if (location.state && location.state.packageId) {
      const pkg = packageDetails[location.state.packageId] || createBasicPackageData(location.state.packageId);
      if (pkg) {
        setPackageData(pkg);
      } else {
        // If package not found, redirect to packages page
        navigate("/packages");
      }
    } else {
      // If no package data, redirect to packages page
      navigate("/packages");
    }
  }, [location, navigate]);

  const [selectedImage, setSelectedImage] = useState(0);

  if (!packageData) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <p>Loading package details...</p>
      </div>
    );
  }

  const handleBookNow = () => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
  
    if (!isLoggedIn) {
      // Save the package the user clicked and show login/signup modal
      setPendingPackage(packageData);
      setShowAuthModal(true);
      return;
    }
  
    navigate("/package-booking", { state: { packageData } });
  };
  
  

  return (
    <div style={styles.container}>
      <Container>
        {/* Header Section */}
        <div style={styles.header}>
          <Button
            variant="outline-secondary"
            onClick={() => navigate("/packages")}
            style={styles.backButton}
          >
            ← Back to Packages
          </Button>
          <h1 style={styles.title}>{packageData.name}</h1>
          <div style={styles.locationRating}>
            <span style={styles.location}>📍 {packageData.location}</span>
            <span style={styles.rating}>
              ⭐ {packageData.rating} ({packageData.reviews} reviews)
            </span>
          </div>
        </div>

        <Row>
          {/* Left Column: Images & Details */}
          <Col md={8}>
            {/* Main Image */}
            <div style={styles.imageSection}>
              <img
                src={packageData.images[selectedImage]}
                alt={packageData.name}
                style={styles.mainImage}
              />
              <div style={styles.imageThumbnails}>
                {packageData.images.map((img, idx) => (
                  <img
                    key={idx}
                    src={img}
                    alt={`${packageData.name} ${idx + 1}`}
                    style={{
                      ...styles.thumbnail,
                      ...(selectedImage === idx ? styles.thumbnailActive : {}),
                    }}
                    onClick={() => setSelectedImage(idx)}
                  />
                ))}
              </div>
            </div>

            {/* Description */}
            <Card style={styles.card}>
              <Card.Body>
                <h3 style={styles.sectionTitle}>About This Package</h3>
                <p style={styles.description}>{packageData.description}</p>
              </Card.Body>
            </Card>

            {/* Itinerary */}
            <Card style={styles.card}>
              <Card.Body>
                <h3 style={styles.sectionTitle}>Itinerary</h3>
                {packageData.itinerary.map((item, idx) => (
                  <div key={idx} style={styles.itineraryItem}>
                    <div style={styles.dayBadge}>Day {item.day}</div>
                    <div style={styles.itineraryContent}>
                      <h5 style={styles.itineraryTitle}>{item.title}</h5>
                      <p style={styles.itineraryDescription}>{item.description}</p>
                    </div>
                  </div>
                ))}
              </Card.Body>
            </Card>

            {/* Features */}
            <Card style={styles.card}>
              <Card.Body>
                <h3 style={styles.sectionTitle}>Highlights</h3>
                <div style={styles.featuresGrid}>
                  {packageData.features.map((feature, idx) => (
                    <Badge key={idx} bg="primary" style={styles.featureBadge}>
                      {feature}
                    </Badge>
                  ))}
                </div>
              </Card.Body>
            </Card>
          </Col>

          {/* Right Column: Booking Card */}
          <Col md={4}>
            <Card style={styles.bookingCard}>
              <Card.Body>
                <div style={styles.priceSection}>
                  <span style={styles.priceLabel}>Starting from</span>
                  <h2 style={styles.price}>₹{packageData.price.toLocaleString()}</h2>
                  <p style={styles.duration}>{packageData.duration}</p>
                </div>

                <div style={styles.inclusionsSection}>
                  <h4 style={styles.inclusionsTitle}>✅ What's Included</h4>
                  <ul style={styles.inclusionsList}>
                    {packageData.inclusions.map((item, idx) => (
                      <li key={idx} style={styles.inclusionItem}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div style={styles.exclusionsSection}>
                  <h4 style={styles.exclusionsTitle}>❌ Not Included</h4>
                  <ul style={styles.exclusionsList}>
                    {packageData.exclusions.map((item, idx) => (
                      <li key={idx} style={styles.exclusionItem}>{item}</li>
                    ))}
                  </ul>
                </div>

                <Button
                  variant="primary"
                  size="lg"
                  style={styles.bookButton}
                  onClick={handleBookNow}
                >
                  Book Now
                </Button>

                <p style={styles.termsText}>
                  * Prices are per person. Terms and conditions apply.
                </p>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        <AuthModal
          show={showAuthModal}
          handleClose={() => setShowAuthModal(false)}
          initialMode="login"
          onLoginSuccess={() => {
            setShowAuthModal(false);
            if (pendingPackage) {
              navigate("/package-booking", { state: { packageData: pendingPackage } });
            }
          }}
        />

      </Container>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: "#f8f9fa",
    minHeight: "100vh",
    padding: "40px 0",
  },
  header: {
    marginBottom: "30px",
  },
  backButton: {
    marginBottom: "15px",
    borderRadius: "20px",
  },
  title: {
    fontSize: "2.5rem",
    fontWeight: "700",
    color: "#222",
    marginBottom: "15px",
  },
  locationRating: {
    display: "flex",
    gap: "20px",
    alignItems: "center",
  },
  location: {
    fontSize: "1.1rem",
    color: "#666",
  },
  rating: {
    fontSize: "1.1rem",
    color: "#0071eb",
    fontWeight: "600",
  },
  imageSection: {
    marginBottom: "30px",
  },
  mainImage: {
    width: "100%",
    height: "500px",
    objectFit: "cover",
    borderRadius: "12px",
    marginBottom: "15px",
  },
  imageThumbnails: {
    display: "flex",
    gap: "10px",
  },
  thumbnail: {
    width: "120px",
    height: "80px",
    objectFit: "cover",
    borderRadius: "8px",
    cursor: "pointer",
    opacity: 0.7,
    transition: "all 0.3s",
    border: "2px solid transparent",
  },
  thumbnailActive: {
    opacity: 1,
    border: "2px solid #0071eb",
  },
  card: {
    border: "none",
    borderRadius: "12px",
    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
    marginBottom: "20px",
  },
  sectionTitle: {
    fontSize: "1.5rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "20px",
  },
  description: {
    fontSize: "1rem",
    color: "#555",
    lineHeight: "1.8",
  },
  itineraryItem: {
    display: "flex",
    gap: "20px",
    marginBottom: "25px",
    paddingBottom: "25px",
    borderBottom: "1px solid #e9ecef",
  },
  dayBadge: {
    backgroundColor: "#0071eb",
    color: "#fff",
    padding: "10px 15px",
    borderRadius: "8px",
    fontWeight: "600",
    minWidth: "80px",
    textAlign: "center",
    height: "fit-content",
  },
  itineraryContent: {
    flex: 1,
  },
  itineraryTitle: {
    fontSize: "1.2rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "8px",
  },
  itineraryDescription: {
    fontSize: "0.95rem",
    color: "#666",
    margin: 0,
  },
  featuresGrid: {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px",
  },
  featureBadge: {
    padding: "8px 15px",
    fontSize: "0.9rem",
    margin: "5px",
  },
  bookingCard: {
    position: "sticky",
    top: "100px",
    border: "none",
    borderRadius: "12px",
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
  },
  priceSection: {
    textAlign: "center",
    paddingBottom: "20px",
    borderBottom: "2px solid #e9ecef",
    marginBottom: "20px",
  },
  priceLabel: {
    fontSize: "0.9rem",
    color: "#666",
    display: "block",
    marginBottom: "5px",
  },
  price: {
    fontSize: "2.5rem",
    fontWeight: "700",
    color: "#0071eb",
    margin: "10px 0",
  },
  duration: {
    fontSize: "1rem",
    color: "#666",
    margin: 0,
  },
  inclusionsSection: {
    marginBottom: "20px",
  },
  inclusionsTitle: {
    fontSize: "1.1rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "15px",
  },
  inclusionsList: {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },
  inclusionItem: {
    padding: "8px 0",
    fontSize: "0.9rem",
    color: "#555",
    borderBottom: "1px solid #f0f0f0",
  },
  exclusionsSection: {
    marginBottom: "20px",
  },
  exclusionsTitle: {
    fontSize: "1.1rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "15px",
  },
  exclusionsList: {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },
  exclusionItem: {
    padding: "8px 0",
    fontSize: "0.9rem",
    color: "#999",
    borderBottom: "1px solid #f0f0f0",
  },
  bookButton: {
    width: "100%",
    padding: "15px",
    fontSize: "1.2rem",
    fontWeight: "600",
    borderRadius: "8px",
    backgroundColor: "#0071eb",
    border: "none",
    marginBottom: "15px",
  },
  termsText: {
    fontSize: "0.85rem",
    color: "#999",
    textAlign: "center",
    margin: 0,
  },
};

export default PackageDetails;

