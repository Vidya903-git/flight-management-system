// src/components/Dashboard.js
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Form, Button} from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const Dashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // UI state
  const [activeSection, setActiveSection] = useState("bookings"); // 'bookings' | 'profile'
  const [bookingsTab, setBookingsTab] = useState("flights"); // 'flights' | 'packages'

  // Profile state
  const [name, setName] = useState(() => localStorage.getItem("userName") || "Praveen");
  const [email, setEmail] = useState(() => localStorage.getItem("userEmail") || "praveen@example.com");
  const [phone, setPhone] = useState(() => localStorage.getItem("userPhone") || "9876543210");
  const [profilePhotoUrl, setProfilePhotoUrl] = useState(() => localStorage.getItem("profilePhoto") || "");

  // Booking lists
  const [flightBookings, setFlightBookings] = useState([]);
  const [packageBookings, setPackageBookings] = useState([]);

  // helper: load stored bookings on mount
  useEffect(() => {
    const f = JSON.parse(localStorage.getItem("flightBookings") || "[]");
    const p = JSON.parse(localStorage.getItem("packageBookings") || "[]");
    setFlightBookings(Array.isArray(f) ? f : []);
    setPackageBookings(Array.isArray(p) ? p : []);
  }, []);

  // If the user navigated to /dashboard with location.state containing booking info,
  // add it to localStorage and update the UI. This handles navigation from BookingConfirmation and PackageBookingConfirmation.
  useEffect(() => {
    if (!location || !location.state) return;

    const s = location.state;

    // If page is bookings, optionally open bookings tab
    if (s.page === "bookings") {
      setActiveSection("bookings");
      if (s.bookingType === "flight") setBookingsTab("flights");
      if (s.bookingType === "package") setBookingsTab("packages");
    }

    // If a bookingData object is passed, unify shape and save
    if (s.bookingData) {
      if (s.bookingType === "flight") {
        const booking = {
          bookingId: s.bookingData.bookingId || s.bookingData.bookingId || `BK${Date.now()}`,
          flightName: s.bookingData.flightName || s.bookingData.airline || "Flight",
          from: s.bookingData.from || s.bookingData.routeFrom || s.bookingData.fromCity || "",
          to: s.bookingData.to || s.bookingData.routeTo || s.bookingData.toCity || "",
          date: s.bookingData.date || s.bookingData.departDate || s.bookingData.travelDate || "",
          passengers: s.bookingData.passengers || 1,
          price: s.bookingData.price || s.bookingData.amount || 0,
          raw: s.bookingData,
          bookingDate: s.bookingData.bookingDate || new Date().toISOString()
        };

        const existing = JSON.parse(localStorage.getItem("flightBookings") || "[]");
        const updated = [...existing, booking];
        localStorage.setItem("flightBookings", JSON.stringify(updated));
        setFlightBookings(updated);
        setActiveSection("bookings");
        setBookingsTab("flights");
      }

      if (s.bookingType === "package") {
        const booking = {
          bookingId: s.bookingData.bookingId || `PKG${Date.now()}`,
          packageName: s.bookingData.packageName || s.bookingData.name || "Package",
          location: s.bookingData.location || "",
          startDate: s.bookingData.startDate || s.bookingData.travelDate || "",
          endDate: s.bookingData.endDate || null,
          travelers: s.bookingData.travelers || s.bookingData.passengers || 1,
          price: s.bookingData.price || s.bookingData.amount || (s.bookingData.pricing && s.bookingData.pricing.finalTotal) || 0,
          image: s.bookingData.image || "",
          raw: s.bookingData,
          bookingDate: s.bookingData.bookingDate || new Date().toISOString()
        };

        const existing = JSON.parse(localStorage.getItem("packageBookings") || "[]");
        const updated = [...existing, booking];
        localStorage.setItem("packageBookings", JSON.stringify(updated));
        setPackageBookings(updated);
        setActiveSection("bookings");
        setBookingsTab("packages");
      }
    }
    // Clear location.state so repeating refreshes won't duplicate; this only affects React Navigation state not persisted storage.
    // Note: cannot mutate location.state directly — just keep logic idempotent on reloads.
    // If you want to clear, you can navigate programmatically without state after adding.
    // Example (optional): navigate("/dashboard", { replace: true });
    // But don't force replace here to avoid losing user context.
  }, [location]);

  // Save profile updates to localStorage
  const handleSaveProfile = () => {
    localStorage.setItem("userName", name);
    localStorage.setItem("userEmail", email);
    localStorage.setItem("userPhone", phone);
    if (profilePhotoUrl) localStorage.setItem("profilePhoto", profilePhotoUrl);
    alert("Profile saved locally.");
  };

  // Remove flight booking
  const cancelFlight = (bookingId) => {
    const updated = flightBookings.filter((b) => b.bookingId !== bookingId);
    localStorage.setItem("flightBookings", JSON.stringify(updated));
    setFlightBookings(updated);
  };

  // Remove package booking
  const cancelPackage = (bookingId) => {
    const updated = packageBookings.filter((b) => b.bookingId !== bookingId);
    localStorage.setItem("packageBookings", JSON.stringify(updated));
    setPackageBookings(updated);
  };


  // Inline styles to match your design direction (soft cards, rounded corners)
  const styles = {
    page: { background: "#eef2f6", minHeight: "100vh", padding: "24px 32px" },
    containerRow: { display: "flex", gap: "28px", alignItems: "flex-start" },
    sidebar: {
      width: 260,
      background: "#fff",
      borderRadius: 12,
      padding: 20,
      boxShadow: "0 6px 24px rgba(15, 20, 25, 0.06)",
    },
    main: { flex: 1 },
    topTitle: { fontSize: 28, fontWeight: 700, marginBottom: 18 },
    card: {
      borderRadius: 14,
      boxShadow: "0 6px 24px rgba(15, 20, 25, 0.06)",
      border: "none",
      background: "#fff",
      padding: 22,
    },
    sectionTitle: { fontSize: 18, fontWeight: 700, marginBottom: 12 },
    smallMuted: { color: "#666", fontSize: 14 },
    bookingCard: {
      padding: 14,
      borderRadius: 12,
      background: "#fafafa",
      marginBottom: 12,
      border: "1px solid #f0f0f0",
    },
    btnPrimary: { background: "#1a73e8", border: "none", borderRadius: 8, padding: "8px 14px" },
    dangerBtn: { background: "#d9534f", border: "none", borderRadius: 8, padding: "6px 12px" },
    profilePhoto: { width: 80, height: 80, borderRadius: "50%", background: "#f0f0f0", objectFit: "cover" },
    navItem: (active) => ({
      padding: "10px 6px",
      cursor: "pointer",
      color: active ? "#1a73e8" : "#222",
      fontWeight: active ? 700 : 500,
    }),
    tabsRow: { display: "flex", gap: 12, marginBottom: 18 },
    tabBtn: (active) => ({
      padding: "8px 14px",
      borderRadius: 10,
      border: active ? "1px solid #1a73e8" : "1px solid transparent",
      background: active ? "#fff" : "transparent",
      cursor: "pointer",
      fontWeight: active ? 700 : 600,
      color: active ? "#1a73e8" : "#444",
      boxShadow: active ? "0 4px 12px rgba(26,115,232,0.08)" : "none",
    }),
  };

  return (
    <div style={styles.page}>
      <div style={styles.topTitle}>MY BOOKINGS</div>

      <div style={styles.containerRow}>
        {/* Sidebar */}
        <div style={styles.sidebar}>
          <div style={{ marginBottom: 18, fontSize: 13, color: "#999" }}>[SIDEBAR]</div>

          <div
            style={styles.navItem(activeSection === "bookings")}
            onClick={() => setActiveSection("bookings")}
            role="button"
          >
            <span style={{ marginRight: 8 }}>●</span> My Bookings
          </div>

          <div
            style={styles.navItem(activeSection === "profile")}
            onClick={() => setActiveSection("profile")}
            role="button"
          >
            <span style={{ marginRight: 8 }}>●</span> Profile
          </div>
        </div>

        {/* Main content */}
        <div style={styles.main}>
          {/* Bookings Section */}
          {activeSection === "bookings" && (
            <div style={styles.card}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={styles.sectionTitle}>Your Bookings</div>
                  <div style={styles.smallMuted}>All your flight and package bookings are listed here</div>
                </div>

                <div style={{ display: "flex", gap: 12 }}>
                  <div style={{ textAlign: "right" }}>
                    {/* optional place for summary stats */}
                    <div style={{ fontSize: 12, color: "#666" }}>Bookings</div>
                    <div style={{ fontWeight: 700, fontSize: 16 }}>
                      {flightBookings.length + packageBookings.length}
                    </div>
                  </div>
                </div>
              </div>

              <hr style={{ margin: "18px 0", borderColor: "#f0f0f0" }} />

              {/* Tabs */}
              <div style={styles.tabsRow}>
                <div
                  style={styles.tabBtn(bookingsTab === "flights")}
                  onClick={() => setBookingsTab("flights")}
                >
                  ✈ Flights ({flightBookings.length})
                </div>
                <div
                  style={styles.tabBtn(bookingsTab === "packages")}
                  onClick={() => setBookingsTab("packages")}
                >
                  📦 Packages ({packageBookings.length})
                </div>
              </div>

              {/* Flights Tab */}
              {bookingsTab === "flights" && (
                <>
                  {flightBookings.length === 0 ? (
                    <div style={{ padding: 28 }}>
                      <div style={{ fontWeight: 600, marginBottom: 8 }}>No Bookings yet.</div>
                      <div style={styles.smallMuted}>Book a flight to see it here.</div>
                    </div>
                  ) : (
                    flightBookings
                      .slice()
                      .reverse()
                      .map((b) => (
                        <div key={b.bookingId} style={styles.bookingCard}>
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <div>
                              <div style={{ fontWeight: 700, fontSize: 16 }}>{b.flightName}</div>
                              <div style={{ color: "#555", marginTop: 6 }}>
                                {b.from} → {b.to}
                              </div>
                              <div style={{ color: "#666", marginTop: 6 }}>
                                Date: {b.date} · Passengers: {b.passengers}
                              </div>
                            </div>

                            <div style={{ textAlign: "right" }}>
                              <div style={{ fontWeight: 700, color: "#28a745", marginBottom: 6 }}>
                                ₹{Number(b.price || 0).toLocaleString()}
                              </div>
                              <div style={{ marginBottom: 8, color: "#777", fontSize: 13 }}>{new Date(b.bookingDate || Date.now()).toLocaleString()}</div>

                              <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                                <Button
                                  size="sm"
                                  variant="outline-primary"
                                  onClick={() =>
                                    navigate("/booking-details", {
                                      state: { bookingType: "flight", bookingData: b },
                                    })
                                  }
                                >
                                  View
                                </Button>

                                <Button size="sm" style={styles.dangerBtn} onClick={() => cancelFlight(b.bookingId)}>
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </>
              )}

              {/* Packages Tab */}
              {bookingsTab === "packages" && (
                <>
                  {packageBookings.length === 0 ? (
                    <div style={{ padding: 28 }}>
                      <div style={{ fontWeight: 600, marginBottom: 8 }}>No Package bookings yet.</div>
                      <div style={styles.smallMuted}>Book a package to see it here.</div>
                    </div>
                  ) : (
                    packageBookings
                      .slice()
                      .reverse()
                      .map((p) => (
                        <div key={p.bookingId} style={styles.bookingCard}>
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                              {p.image ? (
                                // eslint-disable-next-line jsx-a11y/img-redundant-alt
                                <img src={p.image} alt="package" style={{ width: 90, height: 64, objectFit: "cover", borderRadius: 8 }} />
                              ) : (
                                <div style={{ width: 90, height: 64, background: "#f1f3f5", borderRadius: 8 }} />
                              )}

                              <div>
                                <div style={{ fontWeight: 700 }}>{p.packageName}</div>
                                <div style={{ color: "#555", marginTop: 6 }}>{p.location}</div>
                                <div style={{ color: "#666", marginTop: 6 }}>
                                  {p.startDate}{p.endDate ? ` → ${p.endDate}` : ""} · {p.travelers || p.travelers === 0 ? p.travelers : p.travellers || 1} travellers
                                </div>
                              </div>
                            </div>

                            <div style={{ textAlign: "right" }}>
                              <div style={{ fontWeight: 700, color: "#28a745", marginBottom: 6 }}>
                                ₹{Number(p.price || 0).toLocaleString()}
                              </div>
                              <div style={{ marginBottom: 8, color: "#777", fontSize: 13 }}>{new Date(p.bookingDate || Date.now()).toLocaleString()}</div>

                              <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                                <Button
                                  size="sm"
                                  variant="outline-primary"
                                  onClick={() =>
                                    navigate("/booking-details", {
                                      state: { bookingType: "package", bookingData: p },
                                    })
                                  }
                                >
                                  View
                                </Button>

                                <Button size="sm" style={styles.dangerBtn} onClick={() => cancelPackage(p.bookingId)}>
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </>
              )}
            </div>
          )}

          {/* Profile Section */}
          {activeSection === "profile" && (
            <div style={styles.card}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={styles.sectionTitle}>My Profile</div>
                  <div style={styles.smallMuted}>Update your profile details</div>
                </div>

                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <div>
                    {profilePhotoUrl ? (
                      // eslint-disable-next-line jsx-a11y/img-redundant-alt
                      <img src={profilePhotoUrl} alt="profile photo" style={styles.profilePhoto} />
                    ) : (
                      <div style={{ ...styles.profilePhoto, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28 }}>
                        {name ? name[0].toUpperCase() : "U"}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <hr style={{ margin: "18px 0", borderColor: "#f0f0f0" }} />

              <Form>
                <Form.Group className="mb-3" controlId="profileName">
                  <Form.Label>Full Name</Form.Label>
                  <Form.Control value={name} onChange={(e) => setName(e.target.value)} style={{ borderRadius: 10 }} />
                </Form.Group>

                <Form.Group className="mb-3" controlId="profileEmail">
                  <Form.Label>Email</Form.Label>
                  <Form.Control value={email} onChange={(e) => setEmail(e.target.value)} style={{ borderRadius: 10 }} />
                </Form.Group>

                <Form.Group className="mb-3" controlId="profilePhone">
                  <Form.Label>Phone</Form.Label>
                  <Form.Control value={phone} onChange={(e) => setPhone(e.target.value)} style={{ borderRadius: 10 }} />
                </Form.Group>

                <Form.Group className="mb-3" controlId="profilePhoto">
                  <Form.Label>Profile Photo URL</Form.Label>
                  <Form.Control
                    value={profilePhotoUrl}
                    onChange={(e) => setProfilePhotoUrl(e.target.value)}
                    placeholder="Paste a public image URL"
                    style={{ borderRadius: 10 }}
                  />
                </Form.Group>

                <div style={{ display: "flex", gap: 12 }}>
                  <Button style={styles.btnPrimary} onClick={handleSaveProfile}>
                    Save Changes
                  </Button>
                  <Button variant="outline-secondary" onClick={() => {
                    setName("");
                    setEmail("");
                    setPhone("");
                    setProfilePhotoUrl("");
                    localStorage.removeItem("userName");
                    localStorage.removeItem("userEmail");
                    localStorage.removeItem("userPhone");
                    localStorage.removeItem("profilePhoto");
                    alert("Profile cleared.");
                  }}>
                    Reset
                  </Button>
                </div>
              </Form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
