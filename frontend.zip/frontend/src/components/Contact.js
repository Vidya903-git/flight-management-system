// src/pages/Contact.js
import React from "react";

const Contact = () => {
  return (
    <div style={{ background: "#f4f6f8", padding: "60px 20px" }}>
      <img src="https://media.istockphoto.com/id/1450058572/photo/businessman-using-a-laptop-and-touching-on-virtual-screen-contact-icons-consists-of-telephone.jpg?s=612x612&w=0&k=20&c=R5wzCGHu6ZS-8EQpJ2Z1tkSbKGGdJH4apVhFM18EXSM=" alt="Contact" style={{ width: "100%", maxWidth: "700px", height: "400px", objectFit: "cover", borderRadius: "10px", justifyContent: "center", alignItems: "center", display: "flex", margin: "0px 0px 0px 400px"}} />
      <div style={{ maxWidth: "1100px", margin: "auto" }}>
        <h1
          style={{
            fontSize: "38px",
            fontWeight: "800",
            textAlign: "center",
            marginBottom: "10px",
          }}
        >
          Contact Us
        </h1>

        <p
          style={{
            textAlign: "center",
            maxWidth: "750px",
            margin: "0 auto",
            fontSize: "18px",
            color: "#666",
          }}
        >
          We're always here to help you with bookings, cancellations, travel
          planning, and more.
        </p>

        {/* Contact Cards */}
        <div
          style={{
            marginTop: "40px",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: "30px",
          }}
        >
          {/* Address */}
          <div
            style={{
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0px 4px 12px rgba(0,0,0,0.1)",
            }}
          >
            <h3 style={{ fontSize: "22px", fontWeight: "600" }}>Office Address</h3>
            <p style={{ lineHeight: "1.7", fontSize: "16px", color: "#555" }}>
              Wander Way Travels <br />
              2nd Floor, Blue Wave Complex <br />
              MG Road, Bengaluru – 560001 <br />
              India
            </p>
          </div>

          {/* Phone */}
          <div
            style={{
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0px 4px 12px rgba(0,0,0,0.1)",
            }}
          >
            <h3 style={{ fontSize: "22px", fontWeight: "600" }}>Phone Numbers</h3>
            <p style={{ fontSize: "16px", lineHeight: "1.7", color: "#555" }}>
              +91 98765 43210 <br />
              +91 91234 56789
            </p>
          </div>

          {/* Email */}
          <div
            style={{
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0px 4px 12px rgba(0,0,0,0.1)",
            }}
          >
            <h3 style={{ fontSize: "22px", fontWeight: "600" }}>Email</h3>
            <p style={{ fontSize: "16px", lineHeight: "1.7", color: "#555" }}>
              support@wanderway.com <br />
              info@wanderway.com
            </p>
          </div>
        </div>

        {/* Working Hours */}
        <div style={{ marginTop: "50px", textAlign: "center" }}>
          <h2 style={{ fontSize: "28px", fontWeight: "700" }}>Working Hours</h2>
          <p
            style={{
              fontSize: "18px",
              color: "#444",
              marginTop: "10px",
              lineHeight: "1.7",
            }}
          >
            Monday – Saturday <br />
            9:00 AM – 8:00 PM
          </p>
        </div>

        {/* WhatsApp */}
        <div style={{ marginTop: "40px", textAlign: "center" }}>
          <h2 style={{ fontSize: "28px", fontWeight: "700" }}>
            WhatsApp Support
          </h2>
          <p style={{ fontSize: "18px", color: "#444", marginTop: "10px" }}>
            +91 90000 11111
          </p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
