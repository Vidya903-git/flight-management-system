import React, { useState, useEffect } from "react";

import { useNavigate } from "react-router-dom";

import "bootstrap/dist/css/bootstrap.min.css";

import { Container, Row, Col, Form, Button, Navbar, Card } from "react-bootstrap";



const Home = () => {

  const navigate = useNavigate();

  const [tripType, setTripType] = useState("oneway");

  const [formData, setFormData] = useState({

    from: "",

    to: "",

    departDate: "",

    returnDate: "",

    passengers: 1,

    travelClass: "Economy",

  });



  const [fromSuggestions, setFromSuggestions] = useState([]);

  const [toSuggestions, setToSuggestions] = useState([]);

  const [fromAirports, setFromAirports] = useState([]);

  const [toAirports, setToAirports] = useState([]);

  const [selectedCountry, setSelectedCountry] = useState({ field: null, country: null });



  const [selectedAirline, setSelectedAirline] = useState("All");

  const [priceFilter, setPriceFilter] = useState("All");



  // Set today's date as default

  useEffect(() => {

    const today = new Date().toISOString().split("T")[0];

    setFormData(prev => ({

      ...prev,

      departDate: today,

    }));

  }, []);



  const allCities = [

    "Delhi, India",

    "Mumbai, India",

    "Bangalore, India",

    "Hyderabad, India",

    "Chennai, India",

    "Kolkata, India",

    "Dubai, UAE",

    "Paris, France",

    "Singapore",

    "Bangkok, Thailand",

    "New York, USA",

    "London, UK",

  ];



  // Country to airports mapping

  const countryAirports = {

    "India": [

      { name: "Indira Gandhi International Airport", code: "DEL", city: "Delhi" },

      { name: "Chhatrapati Shivaji Maharaj International Airport", code: "BOM", city: "Mumbai" },

      { name: "Kempegowda International Airport", code: "BLR", city: "Bangalore" },

      { name: "Rajiv Gandhi International Airport", code: "HYD", city: "Hyderabad" },

      { name: "Chennai International Airport", code: "MAA", city: "Chennai" },

      { name: "Netaji Subhas Chandra Bose International Airport", code: "CCU", city: "Kolkata" },

      { name: "Cochin International Airport", code: "COK", city: "Kochi" },

      { name: "Sardar Vallabhbhai Patel International Airport", code: "AMD", city: "Ahmedabad" },

    ],

    "UAE": [

      { name: "Dubai International Airport", code: "DXB", city: "Dubai" },

      { name: "Abu Dhabi International Airport", code: "AUH", city: "Abu Dhabi" },

      { name: "Sharjah International Airport", code: "SHJ", city: "Sharjah" },

    ],

    "France": [

      { name: "Charles de Gaulle Airport", code: "CDG", city: "Paris" },

      { name: "Orly Airport", code: "ORY", city: "Paris" },

      { name: "Nice Côte d'Azur Airport", code: "NCE", city: "Nice" },

      { name: "Lyon-Saint Exupéry Airport", code: "LYS", city: "Lyon" },

    ],

    "Singapore": [

      { name: "Singapore Changi Airport", code: "SIN", city: "Singapore" },

    ],

    "Thailand": [

      { name: "Suvarnabhumi Airport", code: "BKK", city: "Bangkok" },

      { name: "Don Mueang International Airport", code: "DMK", city: "Bangkok" },

      { name: "Phuket International Airport", code: "HKT", city: "Phuket" },

    ],

    "USA": [

      { name: "John F. Kennedy International Airport", code: "JFK", city: "New York" },

      { name: "LaGuardia Airport", code: "LGA", city: "New York" },

      { name: "Los Angeles International Airport", code: "LAX", city: "Los Angeles" },

      { name: "Chicago O'Hare International Airport", code: "ORD", city: "Chicago" },

      { name: "Miami International Airport", code: "MIA", city: "Miami" },

    ],

    "UK": [

      { name: "Heathrow Airport", code: "LHR", city: "London" },

      { name: "Gatwick Airport", code: "LGW", city: "London" },

      { name: "Stansted Airport", code: "STN", city: "London" },

      { name: "Manchester Airport", code: "MAN", city: "Manchester" },

    ],

  };



  const handleChange = (e) => {

    const { name, value } = e.target;

    setFormData({ ...formData, [name]: value });



    // Check if user is searching for a country (exact match)

    const countryMatch = Object.keys(countryAirports).find(country =>

      country.toLowerCase() === value.toLowerCase().trim()

    );



    if (name === "from") {

      setFromSuggestions([]);

      setFromAirports([]);

     

      if (countryMatch) {

        // Show airports for the selected country

        setFromAirports(countryAirports[countryMatch]);

        setSelectedCountry({ field: "from", country: countryMatch });

      } else {

        // Show city suggestions

        setFromSuggestions(

          allCities.filter((c) =>

            c.toLowerCase().includes(value.toLowerCase())

          )

        );

        setSelectedCountry({ field: null, country: null });

      }

    }

   

    if (name === "to") {

      setToSuggestions([]);

      setToAirports([]);

     

      if (countryMatch) {

        // Show airports for the selected country

        setToAirports(countryAirports[countryMatch]);

        setSelectedCountry({ field: "to", country: countryMatch });

      } else {

        // Show city suggestions

        setToSuggestions(

          allCities.filter((c) =>

            c.toLowerCase().includes(value.toLowerCase())

          )

        );

        setSelectedCountry({ field: null, country: null });

      }

    }

  };



  const handleSuggestionClick = (field, city) => {

    setFormData({ ...formData, [field]: city });

    if (field === "from") {

      setFromSuggestions([]);

      setFromAirports([]);

    }

    if (field === "to") {

      setToSuggestions([]);

      setToAirports([]);

    }

    setSelectedCountry({ field: null, country: null });

  };



  const handleAirportClick = (field, airport) => {

    const airportDisplay = `${airport.city} (${airport.code}) - ${airport.name}`;

    const updatedFormData = { ...formData, [field]: airportDisplay };

    // derive countries for from/to if available

    const deriveCountryFromString = (val) => {

      if (!val) return null;

      const parts = val.split(",");

      if (parts.length > 1) return parts[parts.length - 1].trim();

      return null;

    };

    const fromCountry =

      field === "from"

        ? (selectedCountry.country || deriveCountryFromString(updatedFormData.from))

        : deriveCountryFromString(updatedFormData.from);

    const toCountry =

      field === "to"

        ? (selectedCountry.country || deriveCountryFromString(updatedFormData.to))

        : deriveCountryFromString(updatedFormData.to);

   

    if (field === "from") {

      setFromAirports([]);

      setFromSuggestions([]);

    }

    if (field === "to") {

      setToAirports([]);

      setToSuggestions([]);

    }

    setSelectedCountry({ field: null, country: null });

    setFormData(updatedFormData);

   

    // Automatically navigate to flight results if all required fields are filled

    const otherField = field === "from" ? "to" : "from";

    if (updatedFormData[otherField] && updatedFormData.departDate) {

      // Both airports and date are filled, navigate to results

      navigate("/flights", {

        state: {

          ...updatedFormData,

          tripType,

          fromCountry,

          toCountry,

        },

      });

    }

  };



  const handleSwap = () => {

    // Swap from and to values

    setFormData({

      ...formData,

      from: formData.to,

      to: formData.from,

    });

    // Also swap suggestions and airports if any

    const tempSuggestions = fromSuggestions;

    const tempAirports = fromAirports;

    setFromSuggestions(toSuggestions);

    setToSuggestions(tempSuggestions);

    setFromAirports(toAirports);

    setToAirports(tempAirports);

    // Reset selected country

    setSelectedCountry({ field: null, country: null });

  };



  const handleSubmit = (e) => {

    e.preventDefault();

   

    // Validate required fields

    if (!formData.from || !formData.to || !formData.departDate) {

      alert("Please fill in all required fields (From, To, and Departure Date)");

      return;

    }



    // Validate that from and to are not the same

    if (formData.from.toLowerCase().trim() === formData.to.toLowerCase().trim()) {

      alert("Departure and destination cannot be the same place!");

      return;

    }



    const getCountry = (val) => {

      if (!val) return null;

      const parts = val.split(",");

      if (parts.length > 1) return parts[parts.length - 1].trim();

      return null;

    };

    const fromCountry = getCountry(formData.from);

    const toCountry = getCountry(formData.to);



    // Navigate to flight results page with search parameters

    navigate("/flights", {

      state: {

        ...formData,

        tripType,

        fromCountry,

        toCountry,

      },

    });

  };



  const styles = {

    navbar: {

      backgroundColor: "#fff",

      boxShadow: "0 2px 10px rgba(0,0,0,0.08)",

      padding: "12px 40px",

    },

    hero: {

      backgroundImage:

        "url('https://images.unsplash.com/photo-1526772662000-3f88f10405ff')",

      backgroundSize: "cover",

      backgroundPosition: "center",

      minHeight: "100vh",

      display: "flex",

      justifyContent: "center",

      alignItems: "center",

      padding: "40px 0",

    },

    searchBox: {

      background: "rgba(255, 255, 255, 0.96)",

      borderRadius: "14px",

      padding: "35px",

      width: "90%",

      maxWidth: "900px",

      boxShadow: "0 4px 25px rgba(0,0,0,0.15)",

      position: "relative",

    },

    heading: {

      fontSize: "1.8rem",

      color: "#222",

      textAlign: "center",

      fontWeight: "600",

      marginBottom: "25px",

    },

    tripType: {

      display: "flex",

      justifyContent: "center",

      gap: "20px",

      marginBottom: "25px",

    },

    tripButton: (active) => ({

      border: "none",

      backgroundColor: active ? "#0071eb" : "#e9ecef",

      color: active ? "#fff" : "#333",

      padding: "8px 18px",

      borderRadius: "20px",

      cursor: "pointer",

      fontWeight: "500",

      transition: "0.3s",

    }),

    input: {

      padding: "12px",

      borderRadius: "8px",

      border: "1px solid #ccc",

      fontSize: "1rem",

      width: "100%",

    },

    swapButton: {

      backgroundColor: "#0071eb",

      color: "#fff",

      border: "none",

      borderRadius: "50%",

      width: "40px",

      height: "40px",

      fontSize: "20px",

      cursor: "pointer",

      display: "flex",

      alignItems: "center",

      justifyContent: "center",

      transition: "all 0.3s",

      boxShadow: "0 2px 8px rgba(0,0,0,0.15)",

    },

    suggestionBox: {

      position: "absolute",

      backgroundColor: "#fff",

      border: "1px solid #ccc",

      borderRadius: "6px",

      zIndex: 1000,

      width: "90%",

      marginTop: "5px",

      boxShadow: "0 4px 10px rgba(0,0,0,0.1)",

    },

    suggestionItem: {

      padding: "10px",

      cursor: "pointer",

    },

    airportBox: {

      position: "absolute",

      backgroundColor: "#fff",

      border: "1px solid #ccc",

      borderRadius: "8px",

      zIndex: 1000,

      width: "100%",

      marginTop: "5px",

      boxShadow: "0 4px 15px rgba(0,0,0,0.15)",

      maxHeight: "400px",

      overflowY: "auto",

    },

    airportHeader: {

      padding: "12px 15px",

      backgroundColor: "#f8f9fa",

      fontWeight: "600",

      color: "#0071eb",

      borderBottom: "1px solid #e9ecef",

      fontSize: "0.95rem",

    },

    airportItem: {

      padding: "12px 15px",

      cursor: "pointer",

      display: "flex",

      alignItems: "center",

      gap: "15px",

      borderBottom: "1px solid #f0f0f0",

      transition: "background-color 0.2s",

    },

    airportCode: {

      backgroundColor: "#0071eb",

      color: "#fff",

      padding: "8px 12px",

      borderRadius: "6px",

      fontWeight: "700",

      fontSize: "0.9rem",

      minWidth: "50px",

      textAlign: "center",

    },

    airportInfo: {

      flex: 1,

    },

    airportCity: {

      fontWeight: "600",

      color: "#222",

      fontSize: "1rem",

      marginBottom: "3px",

    },

    airportName: {

      color: "#666",

      fontSize: "0.85rem",

    },

    button: {

      backgroundColor: "#0071eb",

      border: "none",

      padding: "12px",

      borderRadius: "8px",

      color: "white",

      fontSize: "1rem",

      width: "100%",

      cursor: "pointer",

      transition: "0.3s",

    },

    dealsSection: {

      padding: "70px 0",

      backgroundColor: "#f8f9fa",

      textAlign: "center",

    },

    dealsHeading: {

      fontSize: "1.8rem",

      fontWeight: "600",

      color: "#222",

      marginBottom: "40px",

    },

    filters: {

      display: "flex",

      justifyContent: "center",

      gap: "15px",

      marginBottom: "40px",

      flexWrap: "wrap",

    },

    filterButton: (active) => ({

      backgroundColor: active ? "#0071eb" : "#e9ecef",

      color: active ? "#fff" : "#333",

      border: "none",

      padding: "8px 18px",

      borderRadius: "20px",

      cursor: "pointer",

      transition: "0.3s",

    }),

    cardsContainer: {

      overflowX: "auto",

      overflowY: "hidden",

      padding: "20px 0",

      marginTop: "20px",

      scrollBehavior: "smooth",

      WebkitOverflowScrolling: "touch",

      scrollbarWidth: "thin",

      scrollbarColor: "#0071eb #f0f0f0",

    },

    cardsWrapper: {

      display: "flex",

      gap: "20px",

      paddingBottom: "10px",

      minWidth: "max-content",

    },

    cardWrapper: {

      flex: "0 0 300px",

      minWidth: "300px",

    },

    card: {

      border: "none",

      borderRadius: "12px",

      boxShadow: "0 4px 15px rgba(0,0,0,0.1)",

      overflow: "hidden",

      transition: "transform 0.3s ease",

      cursor: "pointer",

      height: "100%",

    },

    cardImg: {

      height: "200px",

      objectFit: "cover",

    },

    cardBody: {

      padding: "15px",

    },

    cardTitle: {

      fontSize: "1.2rem",

      fontWeight: "600",

      color: "#0071eb",

    },

    cardPrice: {

      fontSize: "1rem",

      color: "#333",

      marginTop: "5px",

    },

    offersSection: {

      padding: "70px 0",

      backgroundColor: "#fff",

      textAlign: "center",

    },

    offersHeading: {

      fontSize: "1.8rem",

      fontWeight: "600",

      color: "#222",

      marginBottom: "40px",

    },

    offersContainer: {

      overflowX: "auto",

      overflowY: "hidden",

      padding: "20px 0",

      marginTop: "20px",

      scrollBehavior: "smooth",

      WebkitOverflowScrolling: "touch",

      scrollbarWidth: "thin",

      scrollbarColor: "#0071eb #f0f0f0",

    },

    offersWrapper: {

      display: "flex",

      gap: "25px",

      paddingBottom: "10px",

      minWidth: "max-content",

      justifyContent: "flex-start",

    },

    offerCard: {

      backgroundColor: "#fff",

      borderRadius: "16px",

      boxShadow: "0 4px 20px rgba(0,0,0,0.1)",

      overflow: "hidden",

      width: "300px",

      minWidth: "300px",

      position: "relative",

      transition: "transform 0.3s ease, box-shadow 0.3s ease",

      cursor: "pointer",

      flex: "0 0 300px",

    },

    offerBadge: {

      position: "absolute",

      top: "15px",

      right: "15px",

      backgroundColor: "#ff4757",

      color: "#fff",

      padding: "8px 15px",

      borderRadius: "20px",

      fontSize: "0.85rem",

      fontWeight: "700",

      zIndex: 10,

      boxShadow: "0 2px 10px rgba(255, 71, 87, 0.3)",

    },

    offerImageContainer: {

      width: "100%",

      height: "180px",

      overflow: "hidden",

    },

    offerImage: {

      width: "100%",

      height: "100%",

      objectFit: "cover",

      transition: "transform 0.3s ease",

    },

    offerContent: {

      padding: "20px",

    },

    offerTitle: {

      fontSize: "1.3rem",

      fontWeight: "600",

      color: "#222",

      marginBottom: "10px",

    },

    offerDescription: {

      fontSize: "0.9rem",

      color: "#666",

      marginBottom: "15px",

      lineHeight: "1.5",

    },

    offerDetails: {

      display: "flex",

      flexDirection: "column",

      gap: "8px",

      marginBottom: "15px",

      padding: "12px",

      backgroundColor: "#f8f9fa",

      borderRadius: "8px",

    },

    offerCode: {

      fontSize: "0.9rem",

      fontWeight: "600",

      color: "#0071eb",

    },

    offerValid: {

      fontSize: "0.85rem",

      color: "#999",

    },

    offerButton: {

      width: "100%",

      padding: "12px",

      backgroundColor: "#0071eb",

      color: "#fff",

      border: "none",

      borderRadius: "8px",

      fontSize: "1rem",

      fontWeight: "600",

      cursor: "pointer",

      transition: "background-color 0.3s",

    },

    footer: {

        backgroundColor: "#001f3f",

        color: "#fff",

        padding: "50px 0 30px",

        marginTop: "50px",

      },

      footerLink: {

        background: "none",

        border: "none",

        padding: "0",

        color: "#ddd",

        textDecoration: "none",

        cursor: "pointer",

        display: "block",

        marginBottom: "8px",

        fontSize: "0.95rem",

        textAlign: "left",

        fontFamily: "inherit",

      },

      footerTitle: {

        fontWeight: "600",

        marginBottom: "10px",

        fontSize: "1rem",

        color: "#fff",

      },

    };



  const offers = [

    {

      title: "Early Bird Special",

      description: "Book 30 days in advance and save big on your next trip!",

      discount: "25% OFF",

      code: "EARLY25",

      validTill: "Dec 31, 2025",

      img: "https://images.unsplash.com/photo-1488646953014-85cb44e25828",

    },

    {

      title: "Weekend Getaway",

      description: "Special weekend flight deals to popular destinations worldwide.",

      discount: "30% OFF",

      code: "WEEKEND30",

      validTill: "Dec 31, 2025",

      img: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800",

    },

    {

      title: "Student Discount",

      description: "Exclusive discounts for students on all domestic flights.",

      discount: "20% OFF",

      code: "STUDENT20",

      validTill: "Dec 31, 2025",

      img: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1",

    },

    {

      title: "Family Package",

      description: "Travel with family and get amazing group discounts!",

      discount: "15% OFF",

      code: "FAMILY15",

      validTill: "Dec 31, 2025",

      img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",

    },

  ];



  const topDeals = [

    {

      city: "Dubai",

      country: "UAE",

      price: 18500,

      airline: "Emirates",

      img: "https://images.unsplash.com/photo-1504275107627-0c2ba7a43dba",

    },

    {

      city: "Paris",

      country: "France",

      price: 42000,

      airline: "Air France",

      img: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",

    },

    {

      city: "Bangkok",

      country: "Thailand",

      price: 15800,

      airline: "Thai Airways",

      img: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9",

    },

    {

      city: "Singapore",

      country: "Singapore",

      price: 22400,

      airline: "Singapore Airlines",

      img: "https://images.unsplash.com/photo-1506744038136-46273834b3fb",

    },

    {

      city: "London",

      country: "UK",

      price: 48000,

      airline: "British Airways",

      img: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg?_gl=1*7unl9t*_ga*MTk1MzMyMjUzNS4xNzYyMzIzMDY4*_ga_8JE65Q40S6*czE3NjIzMjMwNjckbzEkZzEkdDE3NjIzMjMxMDMkajI0JGwwJGgw",

    },

  ];



  const filteredDeals = topDeals.filter((deal) => {

    const airlineMatch = selectedAirline === "All" || deal.airline === selectedAirline;

    const priceMatch =

      priceFilter === "All" ||

      (priceFilter === "Low" && deal.price < 20000) ||

      (priceFilter === "Medium" && deal.price >= 20000 && deal.price < 40000) ||

      (priceFilter === "High" && deal.price >= 40000);

    return airlineMatch && priceMatch;

  });



  const handleSelectDeal = (deal) => {

    // Compose a minimal valid search payload for FlightResults

    const today = new Date().toISOString().split("T")[0];

    const fromCity = "Delhi, India"; // default origin for top deals

    const toCity = `${deal.city}, ${deal.country}`;

    navigate("/flights", {

      state: {

        from: fromCity,

        to: toCity,

        fromCountry: "India",

        toCountry: deal.country,

        departDate: today,

        returnDate: "",

        passengers: 1,

        travelClass: "Economy",

        tripType: "oneway",

      },

    });

  };

  return (

    <div>

      <style>

        {`

          .cards-scroll-container::-webkit-scrollbar,

          .offers-scroll-container::-webkit-scrollbar {

            height: 8px;

          }

          .cards-scroll-container::-webkit-scrollbar-track,

          .offers-scroll-container::-webkit-scrollbar-track {

            background: #f0f0f0;

            border-radius: 10px;

          }

          .cards-scroll-container::-webkit-scrollbar-thumb,

          .offers-scroll-container::-webkit-scrollbar-thumb {

            background: #0071eb;

            border-radius: 10px;

          }

          .cards-scroll-container::-webkit-scrollbar-thumb:hover,

          .offers-scroll-container::-webkit-scrollbar-thumb:hover {

            background: #0056b3;

          }

        `}

      </style>

      {/* ---- Navbar ---- */}

      <Navbar expand="lg" style={styles.navbar}></Navbar>



      {/* ---- Hero Section ---- */}

      <section style={styles.hero}>

        <div style={styles.searchBox}>

          <h2 style={styles.heading}>Search Flights ✈️</h2>



          {/* Trip Type */}

          <div style={styles.tripType}>

            <button

              style={styles.tripButton(tripType === "oneway")}

              onClick={() => setTripType("oneway")}

            >

              One Way

            </button>

            <button

              style={styles.tripButton(tripType === "roundtrip")}

              onClick={() => setTripType("roundtrip")}

            >

              Round Trip

            </button>

          </div>



          {/* Search Form */}

          <Form onSubmit={handleSubmit}>

            <Row className="g-3">

              <Col md={4} style={{ position: "relative" }}>

                <Form.Control

                  type="text"

                  name="from"

                  placeholder="From"

                  value={formData.from}

                  onChange={handleChange}

                  style={styles.input}

                  autoComplete="off"

                />

                {fromSuggestions.length > 0 && (

                  <div style={styles.suggestionBox}>

                    {fromSuggestions.map((city, i) => (

                      <div

                        key={i}

                        style={styles.suggestionItem}

                        onClick={() => handleSuggestionClick("from", city)}

                      >

                        {city}

                      </div>

                    ))}

                  </div>

                )}

                {fromAirports.length > 0 && selectedCountry.field === "from" && (

                  <div style={styles.airportBox}>

                    <div style={styles.airportHeader}>

                      Airports in {selectedCountry.country}

                    </div>

                    {fromAirports.map((airport, i) => (

                      <div

                        key={i}

                        style={styles.airportItem}

                        onClick={() => handleAirportClick("from", airport)}

                        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#f0f7ff")}

                        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}

                      >

                        <div style={styles.airportCode}>{airport.code}</div>

                        <div style={styles.airportInfo}>

                          <div style={styles.airportCity}>{airport.city}</div>

                          <div style={styles.airportName}>{airport.name}</div>

                        </div>

                      </div>

                    ))}

                  </div>

                )}

              </Col>



              {/* Swap Button */}

              <Col md={1} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>

                <button

                  type="button"

                  onClick={handleSwap}

                  style={styles.swapButton}

                  title="Swap From and To"

                  onMouseEnter={(e) => {

                    e.currentTarget.style.backgroundColor = "#0056b3";

                    e.currentTarget.style.transform = "rotate(180deg)";

                  }}

                  onMouseLeave={(e) => {

                    e.currentTarget.style.backgroundColor = "#0071eb";

                    e.currentTarget.style.transform = "rotate(0deg)";

                  }}

                >

                  ⇄

                </button>

              </Col>



              <Col md={4} style={{ position: "relative" }}>

                <Form.Control

                  type="text"

                  name="to"

                  placeholder="To"

                  value={formData.to}

                  onChange={handleChange}

                  style={styles.input}

                  autoComplete="off"

                />

                {toSuggestions.length > 0 && (

                  <div style={styles.suggestionBox}>

                    {toSuggestions.map((city, i) => (

                      <div

                        key={i}

                        style={styles.suggestionItem}

                        onClick={() => handleSuggestionClick("to", city)}

                      >

                        {city}

                      </div>

                    ))}

                  </div>

                )}

                {toAirports.length > 0 && selectedCountry.field === "to" && (

                  <div style={styles.airportBox}>

                    <div style={styles.airportHeader}>

                      Airports in {selectedCountry.country}

                    </div>

                    {toAirports.map((airport, i) => (

                      <div

                        key={i}

                        style={styles.airportItem}

                        onClick={() => handleAirportClick("to", airport)}

                        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#f0f7ff")}

                        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}

                      >

                        <div style={styles.airportCode}>{airport.code}</div>

                        <div style={styles.airportInfo}>

                          <div style={styles.airportCity}>{airport.city}</div>

                          <div style={styles.airportName}>{airport.name}</div>

                        </div>

                      </div>

                    ))}

                  </div>

                )}

              </Col>



              <Col md={3}>

                <Form.Select

                  name="travelClass"

                  value={formData.travelClass}

                  onChange={handleChange}

                  style={styles.input}

                >

                  <option>Economy</option>

                  <option>Premium Economy</option>

                  <option>Business</option>

                  <option>First Class</option>

                </Form.Select>

              </Col>

            </Row>



            <Row className="g-3 mt-3">

              <Col md={4}>

                <Form.Control

                  type="date"

                  name="departDate"

                  value={formData.departDate}

                  onChange={handleChange}

                  style={styles.input}

                />

              </Col>

              {tripType === "roundtrip" && (

                <Col md={4}>

                  <Form.Control

                    type="date"

                    name="returnDate"

                    value={formData.returnDate}

                    onChange={handleChange}

                    style={styles.input}

                  />

                </Col>

              )}

              <Col md={tripType === "roundtrip" ? 4 : 8}>

                <Form.Select

                  name="passengers"

                  value={formData.passengers}

                  onChange={handleChange}

                  style={styles.input}

                >

                  {[1, 2, 3, 4, 5].map((num) => (

                    <option key={num}>

                      {num} Passenger{num > 1 ? "s" : ""}

                    </option>

                  ))}

                </Form.Select>

              </Col>

            </Row>



            <Row className="mt-4">

              <Col>

                <Button type="submit" style={styles.button}>

                  Search Flights

                </Button>

              </Col>

            </Row>

          </Form>

        </div>

      </section>



      {/* ---- Special Offers ---- */}

      <section style={styles.offersSection}>

        <Container>

          <h2 style={styles.offersHeading}>Special Offers 🎁</h2>

          <div style={styles.offersContainer} className="offers-scroll-container">

            <div style={styles.offersWrapper}>

              {offers.map((offer, index) => (

              <div

                key={index}

                style={styles.offerCard}

                onMouseEnter={(e) => {

                  e.currentTarget.style.transform = "translateY(-5px)";

                  e.currentTarget.style.boxShadow = "0 8px 30px rgba(0,0,0,0.15)";

                  const img = e.currentTarget.querySelector("img");

                  if (img) img.style.transform = "scale(1.1)";

                }}

                onMouseLeave={(e) => {

                  e.currentTarget.style.transform = "translateY(0)";

                  e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,0,0,0.1)";

                  const img = e.currentTarget.querySelector("img");

                  if (img) img.style.transform = "scale(1)";

                }}

              >

                <div style={styles.offerBadge}>{offer.discount}</div>

                <div style={styles.offerImageContainer}>

                  <img src={offer.img} alt={offer.title} style={styles.offerImage} />

                </div>

                <div style={styles.offerContent}>

                  <h3 style={styles.offerTitle}>{offer.title}</h3>

                  <p style={styles.offerDescription}>{offer.description}</p>

                  <div style={styles.offerDetails}>

                    <span style={styles.offerCode}>Code: {offer.code}</span>

                    <span style={styles.offerValid}>Valid till {offer.validTill}</span>

                  </div>

                  <button

                    style={styles.offerButton}

                    onClick={() => alert(`Applying offer: ${offer.code}`)}

                    onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#0056b3")}

                    onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#0071eb")}

                  >

                    Apply Now

                  </button>

                </div>

              </div>

              ))}

            </div>

          </div>

        </Container>

      </section>



      {/* ---- Top Deals + Filters ---- */}

      <section style={styles.dealsSection}>

        <Container>

          <h2 style={styles.dealsHeading}>Top Flight Deals 🌏</h2>



          {/* Filters */}

          <div style={styles.filters}>

            <div>

              <span>Airline: </span>

              {["All", "Emirates", "Air France", "Thai Airways", "Singapore Airlines", "British Airways"].map(

                (a) => (

                  <button

                    key={a}

                    style={styles.filterButton(selectedAirline === a)}

                    onClick={() => setSelectedAirline(a)}

                  >

                    {a}

                  </button>

                )

              )}

            </div>



            <div>

              <span>Price: </span>

              {["All", "Low", "Medium", "High"].map((p) => (

                <button

                  key={p}

                  style={styles.filterButton(priceFilter === p)}

                  onClick={() => setPriceFilter(p)}

                >

                  {p}

                </button>

              ))}

            </div>

          </div>



          <div style={styles.cardsContainer} className="cards-scroll-container">

            <div style={styles.cardsWrapper}>

              {filteredDeals.map((deal, index) => (

                <div key={index} style={styles.cardWrapper}>

                  <Card

                    style={styles.card}

                    onMouseOver={(e) =>

                      (e.currentTarget.style.transform = "scale(1.05)")

                    }

                    onMouseOut={(e) =>

                      (e.currentTarget.style.transform = "scale(1)")

                    }

                    onClick={() => handleSelectDeal(deal)}

                  >

                    <Card.Img variant="top" src={deal.img} style={styles.cardImg} />

                    <Card.Body style={styles.cardBody}>

                      <Card.Title style={styles.cardTitle}>

                        {deal.city}, {deal.country}

                      </Card.Title>

                      <Card.Text style={styles.cardPrice}>

                        {deal.airline} — Starting from ₹{deal.price.toLocaleString()}

                      </Card.Text>

                    </Card.Body>

                  </Card>

                </div>

              ))}

            </div>

          </div>

        </Container>

      </section>



      {/* Booking Flights Section */}

<section style={{ padding: "60px 0", backgroundColor: "#fff" }}>

  <Container>

    <h3 className="text-center mb-4" style={{ fontWeight: "600" }}>

      Booking flights with Wander Way

    </h3>

    <Row>

      <Col md={6}>

        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>How does Wander Way work?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Wander Way compares flights across hundreds of airlines and travel agents in seconds,

            showing you the best available prices all in one place — helping you plan smarter trips.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>How can I find the cheapest flight using Wander Way?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Use our flexible search filters and “Everywhere” option to find the lowest-priced destinations.

            You can also compare dates and airlines side-by-side to get the best value.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>Where should I book a flight to right now?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Check out Wander Way’s trending destinations to see popular and safe routes currently open for travel.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>Do I book my flight with Wander Way?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Wander Way helps you compare and find flights. When you’re ready to book,

            we securely redirect you to the airline or travel agent’s website to complete your booking.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>What happens after I have booked my flight?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Once you’ve booked, you’ll receive confirmation and itinerary details directly from the airline or agent.

            Wander Way remains available to help with travel inspiration and planning.

          </p>

        </details>

      </Col>



      <Col md={6}>

        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>Does Wander Way offer hotels too?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Yes! You can compare thousands of hotels, resorts, and homestays globally to find

            the perfect place to stay for your trip.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>What about car hire?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Wander Way allows you to browse and compare car rentals from trusted providers —

            ideal for road trips or flexible travel plans.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>What’s a Price Alert?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            A Price Alert notifies you when the fare for a route changes.

            Enable it on Wander Way and we’ll send updates instantly when prices drop or rise.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>Can I book a flexible flight ticket?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Absolutely. Wander Way highlights flexible ticket options with free cancellation or date changes

            — perfect for uncertain travel plans.

          </p>

        </details>



        <details style={{ marginBottom: "10px", borderBottom: "1px solid #ccc", padding: "10px 0" }}>

          <summary style={{ fontWeight: "500", cursor: "pointer" }}>Can I book flights that emit less CO₂?</summary>

          <p style={{ marginTop: "8px", color: "#555" }}>

            Yes. Wander Way identifies greener flight choices with lower emissions, helping you travel more sustainably.

          </p>

        </details>

      </Col>

    </Row>

  </Container>

</section>



      {/* Footer */}

      <footer style={styles.footer}>

        <Container>

          <Row>

            <Col md={2}>

              <h6 style={styles.footerTitle}>Help</h6>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Privacy Settings</button>

              <button type="button" onClick={() => navigate("/login")} style={styles.footerLink}>Log in</button>

            </Col>



            <Col md={2}>

              <h6 style={styles.footerTitle}>Legal</h6>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Cookie policy</button>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Privacy policy</button>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Terms of service</button>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Company Details</button>

            </Col>



            <Col md={2}>

              <h6 style={styles.footerTitle}>Explore</h6>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Company</button>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Partners</button>

              <button type="button" onClick={() => {}} style={styles.footerLink}>Trips</button>

              <button type="button" onClick={() => {}} style={styles.footerLink}>International Sites</button>

            </Col>

          </Row>



          <div className="text-center mt-4">

            <small>

              © 2025 Wander Way | Cheap flight booking from anywhere, to everywhere.

            </small>

          </div>

        </Container>

      </footer>

    </div>

  );

};



export default Home;