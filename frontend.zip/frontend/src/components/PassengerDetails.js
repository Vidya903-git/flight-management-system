// src/components/PassengerDetails.js
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Container, Form, Button, Card, Row, Col } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const PassengerDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [flight, setFlight] = useState(null);
  const [searchParams, setSearchParams] = useState(null);
  const [flightType, setFlightType] = useState("Domestic");

  const [formData, setFormData] = useState({
    passengerName: "",
    age: "",
    gender: "",
    mobile: "",
    email: "",
    idProofType: "",
    idProofNumber: "",
  });
  const [otpState, setOtpState] = useState({
    generated: "",
    input: "",
    isSent: false,
    isVerified: false,
    sentTo: "",
    sentContactType: "",
  });

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    if (!isLoggedIn) {
      navigate("/login", {
        state: {
          from: "/passenger-details",
          bookingData: location.state,
        },
      });
      return;
    }

    // Get flight and search params from location state
    if (location.state) {
      // Direct navigation (when logged in) or from login (state is bookingData directly)
      if (location.state.flight && location.state.searchParams) {
        setFlight(location.state.flight);
        setSearchParams(location.state.searchParams);
      }
      // If state has bookingData nested
      else if (location.state.bookingData) {
        setFlight(location.state.bookingData.flight);
        setSearchParams(location.state.bookingData.searchParams);
      }
    }

    // Pre-fill email from logged-in user
   
  }, [location, navigate]);

  useEffect(() => {
    if (searchParams) {
      // Determine flight type (Domestic or International)
      const getCountry = (val) => {
        if (!val || typeof val !== "string") return null;
        const parts = val.split(",");
        if (parts.length > 1) return parts[parts.length - 1].trim();
        return null;
      };

      const fromCountry = searchParams.fromCountry || getCountry(searchParams.from);
      const toCountry = searchParams.toCountry || getCountry(searchParams.to);
      const type = fromCountry && toCountry
        ? (fromCountry === toCountry ? "Domestic" : "International")
        : "Domestic";
      setFlightType(type);

      // Set default ID proof type based on flight type
      if (type === "Domestic") {
        setFormData((prev) => ({ ...prev, idProofType: "Aadhaar" }));
      } else {
        setFormData((prev) => ({ ...prev, idProofType: "Passport" }));
      }
    }
  }, [searchParams]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Reset OTP if contact info changes
  useEffect(() => {
    setOtpState((prev) => ({
      ...prev,
      generated: "",
      input: "",
      isSent: false,
      isVerified: false,
      sentTo: "",
      sentContactType: "",
    }));
  }, [formData.mobile, formData.email]);

  const handleSendOtp = () => {
    const contactValue = formData.mobile || formData.email;
    const contactType = formData.mobile ? "mobile" : formData.email ? "email" : "";

    if (!contactValue || !contactType) {
      alert("Please provide a mobile number or email before requesting OTP.");
      return;
    }

    const otp = (Math.floor(100000 + Math.random() * 900000)).toString();
    setOtpState({
      generated: otp,
      input: "",
      isSent: true,
      isVerified: false,
      sentTo: contactValue,
      sentContactType: contactType,
    });

    alert(`Your OTP is ${otp}. (For demo purposes, displayed here)`);
  };

  const handleVerifyOtp = () => {
    if (!otpState.isSent) {
      alert("Please request an OTP first.");
      return;
    }
    if (!otpState.input) {
      alert("Please enter the OTP.");
      return;
    }
    if (otpState.input === otpState.generated) {
      setOtpState((prev) => ({ ...prev, isVerified: true }));
      alert("OTP verification successful!");
    } else {
      alert("Invalid OTP. Please try again.");
    }
  };

  const handleOtpInputChange = (e) => {
    const { value } = e.target;
    setOtpState((prev) => ({ ...prev, input: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.passengerName || !formData.age || !formData.gender || 
        (!formData.mobile && !formData.email) || !formData.idProofType || 
        !formData.idProofNumber) {
      alert("Please fill in all required fields! Provide at least one contact: Mobile or Email.");
      return;
    }

    // Validate email format (only if provided)
    if (formData.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        alert("Please enter a valid email address!");
        return;
      }
    }

    // Validate mobile (10 digits, only if provided)
    if (formData.mobile) {
      if (formData.mobile.length !== 10 || !/^\d+$/.test(formData.mobile)) {
        alert("Please enter a valid 10-digit mobile number!");
        return;
      }
    }

    // Validate age
    const age = parseInt(formData.age);
    if (isNaN(age) || age < 1 || age > 120) {
      alert("Please enter a valid age!");
      return;
    }

    // Validate ID proof format based on selected type
    const idType = formData.idProofType;
    const idValue = formData.idProofNumber.trim();
    const validators = {
      "Aadhaar": (v) => /^\d{12}$/.test(v),
      "Driving License": (v) => /^[A-Za-z0-9-]{6,16}$/.test(v),
      "Passport": (v) => /^[A-PR-WYa-pr-wy][1-9]\d{6}$/.test(v), // typical format
      "Visa": (v) => /^[A-Za-z0-9]{6,15}$/.test(v),
    };
    const isIdValid = validators[idType] ? validators[idType](idValue) : false;
    if (!isIdValid) {
      const friendlyMsg = idType === "Aadhaar"
        ? "Enter a valid 12-digit Aadhaar number."
        : idType === "Driving License"
          ? "Enter a valid Driving License number (6-16 characters)."
          : idType === "Passport"
            ? "Enter a valid Passport number (e.g., A1234567)."
            : "Enter a valid Visa number (6-15 characters).";
      alert(`Invalid ${idType} format. ${friendlyMsg}`);
      return;
    }

    if (!otpState.isVerified) {
      alert("Please verify the OTP before continuing.");
      return;
    }

    // Save passenger details and proceed to booking/payment page
    navigate("/seat-food", {
      state: {
        flight: {
          ...flight,
          type: flightType.toLowerCase(),   // "domestic" or "international"
        },
        searchParams,
        passenger: formData,
      },
    });        
  };

  const styles = {
    container: {
      padding: "40px 20px",
      backgroundColor: "#f8f9fa",
      minHeight: "100vh",
    },
    loadingContainer: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundColor: "#f8f9fa",
    },
    header: {
      backgroundColor: "#fff",
      padding: "20px",
      borderRadius: "10px",
      marginBottom: "30px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
    },
    title: {
      fontSize: "1.8rem",
      fontWeight: "600",
      color: "#222",
      marginBottom: "10px",
    },
    flightInfo: {
      color: "#666",
      fontSize: "1rem",
      marginBottom: "5px",
    },
    flightTypeBadge: {
      display: "inline-block",
      marginLeft: "10px",
      padding: "4px 10px",
      borderRadius: "12px",
      fontSize: "0.75rem",
      fontWeight: "600",
      backgroundColor: flightType === "Domestic" ? "#e6f4ea" : "#e7f0ff",
      color: flightType === "Domestic" ? "#137333" : "#0b57d0",
    },
    card: {
      border: "none",
      borderRadius: "12px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
      marginBottom: "20px",
    },
    cardHeader: {
      backgroundColor: "#0071eb",
      color: "#fff",
      padding: "15px 20px",
      borderRadius: "12px 12px 0 0",
      fontSize: "1.2rem",
      fontWeight: "600",
    },
    cardBody: {
      padding: "30px",
    },
    formGroup: {
      marginBottom: "20px",
    },
    label: {
      fontWeight: "500",
      color: "#333",
      marginBottom: "8px",
      display: "block",
    },
    required: {
      color: "#dc3545",
      marginLeft: "3px",
    },
    input: {
      width: "100%",
      padding: "10px 15px",
      borderRadius: "8px",
      border: "1px solid #ccc",
      fontSize: "1rem",
    },
    select: {
      width: "100%",
      padding: "10px 15px",
      borderRadius: "8px",
      border: "1px solid #ccc",
      fontSize: "1rem",
      backgroundColor: "#fff",
    },
    radioGroup: {
      display: "flex",
      gap: "20px",
      marginTop: "8px",
    },
    radioLabel: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      cursor: "pointer",
      fontWeight: "normal",
    },
    submitButton: {
      backgroundColor: "#0071eb",
      border: "none",
      padding: "12px 40px",
      borderRadius: "8px",
      color: "white",
      fontWeight: "600",
      fontSize: "1rem",
      cursor: "pointer",
      width: "100%",
      marginTop: "20px",
    },
    infoBox: {
      backgroundColor: "#e7f0ff",
      border: "1px solid #0b57d0",
      borderRadius: "8px",
      padding: "15px",
      marginBottom: "20px",
      color: "#0b57d0",
      fontSize: "0.9rem",
    },
    otpSection: {
      marginBottom: "25px",
      padding: "20px",
      border: "1px dashed #0071eb",
      borderRadius: "10px",
      backgroundColor: "#f0f6ff",
    },
    otpControls: {
      display: "flex",
      gap: "15px",
      flexWrap: "wrap",
      alignItems: "center",
    },
    otpButton: {
      minWidth: "130px",
    },
    otpInput: {
      width: "180px",
      padding: "10px 15px",
      borderRadius: "8px",
      border: "1px solid #ccc",
      fontSize: "1rem",
    },
    otpHelp: {
      display: "block",
      marginTop: "8px",
      color: "#0b57d0",
    },
  };

  if (!flight || !searchParams) {
    return (
      <div style={styles.loadingContainer}>
        <p>Loading passenger details form...</p>
      </div>
    );
  }

  const idProofOptions = flightType === "Domestic"
    ? ["Aadhaar", "Driving License"]
    : ["Passport", "Visa"];

  return (
    <div style={styles.container}>
      <Container>
        {/* Header */}
        <div style={styles.header}>
          <h2 style={styles.title}>
            Passenger Details
            <span style={styles.flightTypeBadge}>{flightType}</span>
          </h2>
          <p style={styles.flightInfo}>
            <strong>Flight:</strong> {searchParams.from} → {searchParams.to}
          </p>
          <p style={styles.flightInfo}>
            <strong>Airline:</strong> {flight.airline} | <strong>Class:</strong> {flight.class} | <strong>Date:</strong> {searchParams.departDate}
          </p>
          <p style={styles.flightInfo}>
            <strong>Price:</strong> ₹{flight.price.toLocaleString()} | <strong>Passengers:</strong> {searchParams.passengers || 1}
          </p>
        </div>

        {/* Info Box */}
        {flightType === "International" && (
          <div style={styles.infoBox}>
            <strong>⚠️ International Flight:</strong> Please ensure you have a valid Passport and Visa (if required) for your destination.
          </div>
        )}

        {/* Passenger Details Form */}
        <Card style={styles.card}>
          <div style={styles.cardHeader}>✅ Passenger Information</div>
          <div style={styles.cardBody}>
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col md={6}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ Passenger Name <span style={styles.required}>*</span>
                    </label>
                    <Form.Control
                      type="text"
                      name="passengerName"
                      value={formData.passengerName}
                      onChange={handleChange}
                      placeholder="Enter full name as per ID"
                      required
                      style={styles.input}
                    />
                  </div>
                </Col>

                <Col md={3}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ Age <span style={styles.required}>*</span>
                    </label>
                    <Form.Control
                      type="number"
                      name="age"
                      value={formData.age}
                      onChange={handleChange}
                      placeholder="Age"
                      min="1"
                      max="120"
                      required
                      style={styles.input}
                    />
                  </div>
                </Col>

                <Col md={3}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ Gender <span style={styles.required}>*</span>
                    </label>
                    <div style={styles.radioGroup}>
                      <label style={styles.radioLabel}>
                        <input
                          type="radio"
                          name="gender"
                          value="Male"
                          checked={formData.gender === "Male"}
                          onChange={handleChange}
                          required
                        />
                        Male
                      </label>
                      <label style={styles.radioLabel}>
                        <input
                          type="radio"
                          name="gender"
                          value="Female"
                          checked={formData.gender === "Female"}
                          onChange={handleChange}
                          required
                        />
                        Female
                      </label>
                      <label style={styles.radioLabel}>
                        <input
                          type="radio"
                          name="gender"
                          value="Other"
                          checked={formData.gender === "Other"}
                          onChange={handleChange}
                          required
                        />
                        Other
                      </label>
                    </div>
                  </div>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ Mobile Number <span style={styles.required}>*</span> <small style={{ color: "#888", fontWeight: "normal" }}>(optional if Email provided)</small>
                    </label>
                    <Form.Control
                      type="tel"
                      name="mobile"
                      value={formData.mobile}
                      onChange={handleChange}
                      placeholder="10-digit mobile number"
                      maxLength="10"
                      style={styles.input}
                    />
                  </div>
                </Col>

                <Col md={6}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ Email Address <span style={styles.required}>*</span> <small style={{ color: "#888", fontWeight: "normal" }}>(optional if Mobile provided)</small>
                    </label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Enter email address"
                      style={styles.input}
                    />
                  </div>
                </Col>
              </Row>

              <Row>
                <Col md={12}>
                  <div style={styles.otpSection}>
                    <label style={styles.label}>
                      🔐 OTP Verification <span style={styles.required}>*</span>
                    </label>
                    <div style={styles.otpControls}>
                      <Button
                        type="button"
                        variant="outline-primary"
                        onClick={handleSendOtp}
                        style={styles.otpButton}
                      >
                        {otpState.isSent ? "Resend OTP" : "Send OTP"}
                      </Button>
                      <Form.Control
                        type="text"
                        placeholder="Enter OTP"
                        value={otpState.input}
                        onChange={handleOtpInputChange}
                        maxLength="6"
                        style={styles.otpInput}
                        disabled={!otpState.isSent || otpState.isVerified}
                      />
                      <Button
                        type="button"
                        variant="success"
                        onClick={handleVerifyOtp}
                        style={styles.otpButton}
                        disabled={!otpState.isSent || otpState.isVerified}
                      >
                        Verify OTP
                      </Button>
                    </div>
                    {otpState.isSent && !otpState.isVerified && (
                      <small style={styles.otpHelp}>
                        OTP sent to {otpState.sentContactType === "mobile" ? "mobile" : "email"}: <strong>{otpState.sentTo}</strong>
                      </small>
                    )}
                    {otpState.isVerified && (
                      <small style={{ ...styles.otpHelp, color: "#137333" }}>
                        ✅ OTP verified
                      </small>
                    )}
                  </div>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ ID Proof Type <span style={styles.required}>*</span>
                    </label>
                    <Form.Select
                      name="idProofType"
                      value={formData.idProofType}
                      onChange={handleChange}
                      required
                      style={styles.select}
                    >
                      {idProofOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </Form.Select>
                    {flightType === "Domestic" && (
                      <small style={{ color: "#666", marginTop: "5px", display: "block" }}>
                        For Domestic flights: Aadhaar or Driving License
                      </small>
                    )}
                    {flightType === "International" && (
                      <small style={{ color: "#666", marginTop: "5px", display: "block" }}>
                        For International flights: Passport or Visa required
                      </small>
                    )}
                  </div>
                </Col>

                <Col md={6}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      ✅ ID Proof Number <span style={styles.required}>*</span>
                    </label>
                    <Form.Control
                      type="text"
                      name="idProofNumber"
                      value={formData.idProofNumber}
                      onChange={handleChange}
                      placeholder={
                        formData.idProofType === "Aadhaar"
                          ? "12-digit Aadhaar number"
                          : formData.idProofType === "Driving License"
                          ? "Driving License number"
                          : formData.idProofType === "Passport"
                          ? "Passport number"
                          : "Visa number"
                      }
                      required
                      style={styles.input}
                    />
                  </div>
                </Col>
              </Row>

              <Button type="submit" style={styles.submitButton}>
                Continue to Payment
              </Button>
            </Form>
          </div>
        </Card>
      </Container>
    </div>
  );
};

export default PassengerDetails;

