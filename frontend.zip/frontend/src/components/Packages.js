// src/components/Packages.js
import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Carousel, Container, Row, Col, Card, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const Packages = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Featured package offers for the slider
  // packageId maps to the actual package ID in allPackages for navigation
  const featuredOffers = [
    {
      id: 1,
      title: "European Grand Tour",
      description: "Explore 5 countries in 10 days - Paris, Rome, Barcelona, Amsterdam & London",
      price: "₹1,25,000",
      originalPrice: "₹1,75,000",
      discount: "28% OFF",
      duration: "10 Days / 9 Nights",
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=1200&h=600&fit=crop",
      badge: "Best Seller",
      packageId: 1, // Maps to Paris Romance package
    },
    {
      id: 2,
      title: "Bali Paradise Package",
      description: "Luxury beach resorts, spa treatments, and cultural tours in beautiful Bali",
      price: "₹45,000",
      originalPrice: "₹65,000",
      discount: "30% OFF",
      duration: "7 Days / 6 Nights",
      image: "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?w=1200&h=600&fit=crop",
      badge: "Popular",
      packageId: 7, // Maps to Thailand Adventure (closest beach/Asia package)
    },
    {
      id: 3,
      title: "Dubai Luxury Escape",
      description: "5-star hotels, desert safari, Burj Khalifa visit, and shopping spree",
      price: "₹55,000",
      originalPrice: "₹75,000",
      discount: "26% OFF",
      duration: "5 Days / 4 Nights",
      image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200&h=600&fit=crop",
      badge: "Limited Time",
      packageId: 4, // Maps to Maldives Paradise (luxury package)
    },
    {
      id: 4,
      title: "Swiss Alps Adventure",
      description: "Mountain peaks, scenic train rides, and charming alpine villages",
      price: "₹1,85,000",
      originalPrice: "₹2,25,000",
      discount: "18% OFF",
      duration: "8 Days / 7 Nights",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&h=600&fit=crop",
      badge: "New",
      packageId: 9, // Maps to Iceland Northern Lights (adventure/mountain package)
    },
  ];

  // All available packages with categories from Travel page
  const allPackages = [
    {
      id: 1,
      name: "Paris Romance",
      location: "Paris, France",
      price: "₹65,000",
      duration: "5 Days / 4 Nights",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400&h=300&fit=crop",
      features: ["Eiffel Tower Visit", "Louvre Museum", "River Cruise"],
      category: "Romantic Escapes",
    },
    {
      id: 2,
      name: "Tokyo Discovery",
      location: "Tokyo, Japan",
      price: "₹75,000",
      duration: "6 Days / 5 Nights",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=300&fit=crop",
      features: ["Shibuya Crossing", "Temples Tour", "Sushi Experience"],
      category: "Photography Tours",
    },
    {
      id: 3,
      name: "Santorini Sunset",
      location: "Santorini, Greece",
      price: "₹95,000",
      duration: "4 Days / 3 Nights",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=400&h=300&fit=crop",
      features: ["Sunset Views", "Wine Tasting", "Beach Hopping"],
      category: "Romantic Escapes",
    },
    {
      id: 4,
      name: "Maldives Paradise",
      location: "Maldives",
      price: "₹1,15,000",
      duration: "6 Days / 5 Nights",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400&h=300&fit=crop",
      features: ["Water Villa", "Snorkeling", "Spa Sessions"],
      category: "Luxury Resorts",
    },
    {
      id: 5,
      name: "New York City",
      location: "New York, USA",
      price: "₹1,25,000",
      duration: "7 Days / 6 Nights",
      rating: 4.6,
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400&h=300&fit=crop",
      features: ["Statue of Liberty", "Broadway Show", "Central Park"],
      category: "Photography Tours",
    },
    {
      id: 6,
      name: "Singapore Explorer",
      location: "Singapore",
      price: "₹45,000",
      duration: "4 Days / 3 Nights",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=400&h=300&fit=crop",
      features: ["Marina Bay", "Gardens by the Bay", "Sentosa Island"],
      category: "Photography Tours",
    },
    {
      id: 7,
      name: "Thailand Adventure",
      location: "Bangkok & Phuket",
      price: "₹55,000",
      duration: "6 Days / 5 Nights",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=400&h=300&fit=crop",
      features: ["Temples Tour", "Beach Activities", "Thai Massage"],
      category: "Adventure Hikes",
    },
    {
      id: 8,
      name: "London Heritage",
      location: "London, UK",
      price: "₹85,000",
      duration: "5 Days / 4 Nights",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=400&h=300&fit=crop",
      features: ["Big Ben", "Tower Bridge", "Westminster Abbey"],
      category: "Photography Tours",
    },
    {
      id: 9,
      name: "Iceland Northern Lights",
      location: "Reykjavik, Iceland",
      price: "₹1,45,000",
      duration: "6 Days / 5 Nights",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
      features: ["Aurora Viewing", "Blue Lagoon", "Golden Circle"],
      category: "Arctic Expeditions",
    },
    {
      id: 10,
      name: "African Safari Adventure",
      location: "Serengeti, Tanzania",
      price: "₹1,35,000",
      duration: "7 Days / 6 Nights",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=400&h=300&fit=crop",
      features: ["Big Five Safari", "Game Drives", "Lodge Stay"],
      category: "Wildlife Safaris",
    },
    {
      id: 11,
      name: "Kenya Wildlife Safari",
      location: "Masai Mara, Kenya",
      price: "₹1,20,000",
      duration: "6 Days / 5 Nights",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=400&h=300&fit=crop",
      features: ["Wildebeest Migration", "Hot Air Balloon", "Cultural Tours"],
      category: "Wildlife Safaris",
    },
    {
      id: 12,
      name: "Indian Tiger Safari",
      location: "Ranthambore, India",
      price: "₹45,000",
      duration: "4 Days / 3 Nights",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=300&fit=crop",
      features: ["Tiger Spotting", "Jungle Safari", "Heritage Fort Visit"],
      category: "Wildlife Safaris",
    },
  ];

  // Categories from Travel page
  const travelCategories = ["All", "Adventure Hikes", "Photography Tours", "Romantic Escapes", "Arctic Expeditions", "Luxury Resorts", "Wildlife Safaris"];

  const [selectedCategory, setSelectedCategory] = useState("All");

  // Set category from location state if provided (from Travel.js category click)
  useEffect(() => {
    if (location.state && location.state.category) {
      setSelectedCategory(location.state.category);
    }
  }, [location.state]);

  const filteredPackages = allPackages.filter((pkg) => {
    if (selectedCategory === "All") return true;
    return pkg.category === selectedCategory;
  });

  return (
    <div style={styles.container}>
      {/* ===== Featured Offers Slider ===== */}
      <section style={styles.sliderSection}>
        <Container>
          <h2 style={styles.sliderTitle}>Special Package Offers 🎁</h2>
          <Carousel
            fade
            interval={4000}
            style={styles.carousel}
            prevIcon={
              <span
                aria-hidden="true"
                className="carousel-control-prev-icon"
                style={{ backgroundColor: "rgba(0,0,0,0.3)", zIndex: 0 }}
              />
            }
            nextIcon={
              <span
                aria-hidden="true"
                className="carousel-control-next-icon"
                style={{ backgroundColor: "rgba(0,0,0,0.3)", zIndex: 0 }}
              />
            }
            prevLabel=""
            nextLabel=""
          >


            {featuredOffers.map((offer) => (
              <Carousel.Item key={offer.id} style={{position: "relative",zIndex: 1}}>
                <div style={styles.sliderItem}>
                  <img
                    src={offer.image}
                    alt={offer.title}
                    style={styles.sliderImage}
                  />
                  <Carousel.Caption   style={{
                    ...styles.caption,
                    position: "absolute",
                    zIndex: 99999,
                    pointerEvents: "auto",
                    }}
                  >
                    <div style={styles.offerBadge}>{offer.badge}</div>
                    <div style={styles.captionContent}>
                      <h3 style={styles.offerTitle}>{offer.title}</h3>
                      <p style={styles.offerDescription}>{offer.description}</p>
                      <div style={styles.offerDetails}>
                        <div style={styles.priceContainer}>
                          <span style={styles.originalPrice}>{offer.originalPrice}</span>
                          <span style={styles.currentPrice}>{offer.price}</span>
                          <span style={styles.discount}>{offer.discount}</span>
                        </div>
                        <p style={styles.duration}>{offer.duration}</p>
                      </div>
                      <Button
                        variant="light"
                        size="lg"
                        style={{
                          ...styles.bookButton,
                          position: "relative",
                          zIndex: 999999,
                          pointerEvents: "auto",
                          cursor: "pointer",
                          marginLeft:"200px"
                        }}

                        onClick={() => navigate("/package-details", { state: { packageId: offer.packageId } })}
                      >
                        Book Now
                      </Button>
                    </div>
                  </Carousel.Caption>
                </div>
              </Carousel.Item>
            ))}
          </Carousel>
        </Container>
      </section>

      {/* ===== All Packages Section ===== */}
      <section style={styles.packagesSection}>
        <Container>
          <h2 style={styles.sectionTitle}>Explore Our Packages 🌍</h2>
          
          {/* Category Filters */}
          <div style={styles.filters}>
            {travelCategories.map((category) => (
              <button
                key={category}
                style={styles.filterButton(selectedCategory === category)}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Packages Grid */}
          <Row className="g-4">
            {filteredPackages.map((pkg) => (
              <Col key={pkg.id} xs={12} sm={6} md={4} lg={4}>
                <Card
                  style={styles.packageCard}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-8px)";
                    e.currentTarget.style.boxShadow = "0 8px 25px rgba(0,0,0,0.15)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.boxShadow = "0 4px 15px rgba(0,0,0,0.1)";
                  }}
                >
                  <div style={styles.imageContainer}>
                    <Card.Img
                      variant="top"
                      src={pkg.image}
                      style={styles.cardImage}
                    />
                    <div style={styles.ratingBadge}>
                      ⭐ {pkg.rating}
                    </div>
                  </div>
                  <Card.Body style={styles.cardBody}>
                    <Card.Title style={styles.cardTitle}>{pkg.name}</Card.Title>
                    <Card.Text style={styles.location}>{pkg.location}</Card.Text>
                    <div style={styles.features}>
                      {pkg.features.slice(0, 2).map((feature, idx) => (
                        <span key={idx} style={styles.featureTag}>
                          {feature}
                        </span>
                      ))}
                    </div>
                    <div style={styles.packageFooter}>
                      <div>
                        <p style={styles.price}>{pkg.price}</p>
                        <p style={styles.durationText}>{pkg.duration}</p>
                      </div>
                      <Button
                        variant="primary"
                        style={styles.viewButton}
                        onClick={() => navigate("/package-details", { state: { packageId: pkg.id } })}
                      >
                        View Details
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* ===== Footer ===== */}
      <footer style={styles.footer}>
        <Container>
          <p>© 2025 Wander Way | Discover amazing travel packages</p>
        </Container>
      </footer>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: "#f8f9fa",
    minHeight: "100vh",
  },
  sliderSection: {
    padding: "40px 0 60px",
    backgroundColor: "#fff",
  },
  sliderTitle: {
    fontSize: "2rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "30px",
    textAlign: "center",
  },
  carousel: {
    borderRadius: "15px",
    overflow: "hidden",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
  },
  sliderItem: {
    position: "relative",
    height: "500px",
    overflow: "hidden",
  },
  sliderImage: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
  },
  caption: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    background: "linear-gradient(to top, rgba(0,0,0,0.8), rgba(0,0,0,0.3), transparent)",
    padding: "40px",
    textAlign: "left",
  },
  captionContent: {
    maxWidth: "600px",
  },
  offerBadge: {
    display: "inline-block",
    backgroundColor: "#ff4757",
    color: "#fff",
    padding: "6px 15px",
    borderRadius: "20px",
    fontSize: "0.85rem",
    fontWeight: "700",
    marginBottom: "15px",
  },
  offerTitle: {
    fontSize: "2.5rem",
    fontWeight: "700",
    color: "#fff",
    marginBottom: "15px",
    textShadow: "2px 2px 4px rgba(0,0,0,0.5)",
  },
  offerDescription: {
    fontSize: "1.1rem",
    color: "#f0f0f0",
    marginBottom: "20px",
    lineHeight: "1.6",
  },
  offerDetails: {
    marginBottom: "25px",
  },
  priceContainer: {
    display: "flex",
    alignItems: "center",
    gap: "15px",
    marginBottom: "10px",
  },
  originalPrice: {
    fontSize: "1.2rem",
    color: "#ccc",
    textDecoration: "line-through",
  },
  currentPrice: {
    fontSize: "2rem",
    fontWeight: "700",
    color: "#fff",
  },
  discount: {
    fontSize: "1rem",
    backgroundColor: "#28a745",
    color: "#fff",
    padding: "5px 12px",
    borderRadius: "15px",
    fontWeight: "600",
  },
  duration: {
    fontSize: "1rem",
    color: "#f0f0f0",
    margin: 0,
  },
  bookButton: {
    padding: "12px 30px",
    fontSize: "1.1rem",
    fontWeight: "600",
    borderRadius: "25px",
    backgroundColor: "#fff",
    color: "#0071eb",
    border: "none",
    transition: "all 0.3s",
  },
  packagesSection: {
    padding: "60px 0",
  },
  sectionTitle: {
    fontSize: "2rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "40px",
    textAlign: "center",
  },
  filters: {
    display: "flex",
    justifyContent: "center",
    gap: "15px",
    marginBottom: "40px",
    flexWrap: "wrap",
  },
  filterButton: (active) => ({
    backgroundColor: active ? "#0071eb" : "#e9ecef",
    color: active ? "#fff" : "#333",
    border: "none",
    padding: "10px 20px",
    borderRadius: "25px",
    cursor: "pointer",
    fontWeight: "500",
    fontSize: "0.95rem",
    transition: "all 0.3s",
    boxShadow: active ? "0 2px 8px rgba(0,113,235,0.3)" : "none",
  }),
  packageCard: {
    border: "none",
    borderRadius: "15px",
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
    overflow: "hidden",
    transition: "all 0.3s ease",
    height: "100%",
    display: "flex",
    flexDirection: "column",
  },
  imageContainer: {
    position: "relative",
    height: "220px",
    overflow: "hidden",
  },
  cardImage: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transition: "transform 0.3s ease",
  },
  ratingBadge: {
    position: "absolute",
    top: "10px",
    right: "10px",
    backgroundColor: "rgba(255,255,255,0.95)",
    color: "#333",
    padding: "5px 12px",
    borderRadius: "20px",
    fontSize: "0.85rem",
    fontWeight: "600",
    boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
  },
  cardBody: {
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  cardTitle: {
    fontSize: "1.3rem",
    fontWeight: "600",
    color: "#222",
    marginBottom: "8px",
  },
  location: {
    color: "#666",
    fontSize: "0.95rem",
    marginBottom: "15px",
  },
  features: {
    display: "flex",
    gap: "8px",
    marginBottom: "20px",
    flexWrap: "wrap",
  },
  featureTag: {
    backgroundColor: "#f0f7ff",
    color: "#0071eb",
    padding: "5px 12px",
    borderRadius: "15px",
    fontSize: "0.8rem",
    fontWeight: "500",
  },
  packageFooter: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginTop: "auto",
    paddingTop: "15px",
    borderTop: "1px solid #e9ecef",
  },
  price: {
    fontSize: "1.5rem",
    fontWeight: "700",
    color: "#0071eb",
    margin: 0,
  },
  durationText: {
    fontSize: "0.85rem",
    color: "#999",
    margin: "5px 0 0 0",
  },
  viewButton: {
    backgroundColor: "#0071eb",
    border: "none",
    padding: "8px 20px",
    borderRadius: "20px",
    fontWeight: "500",
    transition: "background-color 0.3s",
  },
  footer: {
    backgroundColor: "#001f3f",
    color: "#fff",
    padding: "30px 0",
    textAlign: "center",
    marginTop: "60px",
  },
};

export default Packages;

