// src/components/Travel.js
import React from "react";
import { useNavigate } from "react-router-dom";
import { Carousel, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const Travel = () => {
  const navigate = useNavigate();

  const categories = [
    { name: "Adventure Hikes", image: "https://sp.yimg.com/ib/th/id/OIP.pClLRdWnL9aU1O4zb8C2jwHaE8?pid=Api&w=148&h=148&c=7&rs=1" },
    { name: "Photography Tours", image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2f/fc/4d/04/caption.jpg?w=500&h=400&s=1" },
    { name: "Romantic Escapes", image: "https://tse1.mm.bing.net/th/id/OIP.OcksMhxurl4vc_Lmt_TRhgHaDt?pid=Api&rs=1&c=1&qlt=95&w=203&h=101" },
    { name: "Arctic Expeditions", image: "https://tse1.mm.bing.net/th/id/OIP._9erqMp41f4aaRLtZ8E9oAHaE6?pid=Api&rs=1&c=1&qlt=95&w=132&h=87" },
    { name: "Luxury Resorts", image: "https://media.istockphoto.com/id/2186161005/photo/woman-relaxing-with-drink-by-tropical-pool.jpg?b=1&s=612x612&w=0&k=20&c=AvQ5jPhzQgGoQTG46yhVy7PTzorzCSvx087lj8u-Tjo=" },
    { name: "Wildlife Safaris", image: "https://tse1.mm.bing.net/th/id/OIP.Y1jQXkEBZBX6EKGkLcCl5gHaEc?pid=Api&P=0&h=180" },
  ];

  const handleCategoryClick = (categoryName) => {
    navigate("/packages", { state: { category: categoryName } });
  };

  // Popular packages with packageId mapping to Packages.js
  const packages = [
    { name: "Paris Romance", price: "₹65,000", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400&h=300&fit=crop", packageId: 1 },
    { name: "Tokyo Discovery", price: "₹75,000", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=300&fit=crop", packageId: 2 },
    { name: "Maldives Paradise", price: "₹1,15,000", image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400&h=300&fit=crop", packageId: 4 },
    { name: "African Safari Adventure", price: "₹1,35,000", image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=400&h=300&fit=crop", packageId: 10 },
    { name: "Iceland Northern Lights", price: "₹1,45,000", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop", packageId: 9 },
  ];

  const handlePackageClick = (packageId) => {
    navigate("/package-details", { state: { packageId } });
  };

  return (
    <div style={styles.container}>
      {/* ===== Slider ===== */}
      <Carousel fade interval={3000} style={{ marginBottom: "40px" }}>
        <Carousel.Item>
          <img
            src="https://images.pexels.com/photos/346885/pexels-photo-346885.jpeg?_gl=1*1bay5ja*_ga*MTk1MzMyMjUzNS4xNzYyMzIzMDY4*_ga_8JE65Q40S6*czE3NjIzMjMwNjckbzEkZzEkdDE3NjIzMjMxMDMkajI0JGwwJGgwe"
            alt="slide1"
              style={styles.sliderImage}
          />
          <Carousel.Caption>
            <h3>Explore the World</h3>
            <p>Find your dream destination with WanderWay Travels</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg?_gl=1*1bcierg*_ga*MTk1MzMyMjUzNS4xNzYyMzIzMDY4*_ga_8JE65Q40S6*czE3NjIzMjMwNjckbzEkZzEkdDE3NjIzMjMxMDMkajI0JGwwJGgw"
            alt="slide2"
            style={styles.sliderImage}
          />
          <Carousel.Caption>
            <h3>Relax by the Beach</h3>
            <p>Luxury resorts and exotic destinations await you</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            src="https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg?_gl=1*7unl9t*_ga*MTk1MzMyMjUzNS4xNzYyMzIzMDY4*_ga_8JE65Q40S6*czE3NjIzMjMwNjckbzEkZzEkdDE3NjIzMjMxMDMkajI0JGwwJGgw"
            alt="slide3"
            style={styles.sliderImage}
          />
          <Carousel.Caption>
            <h3>Adventure Awaits</h3>
            <p>Experience the thrill of mountains and wilderness</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      {/* ===== Travel Categories ===== */}
      <section style={{ marginBottom: "50px" }}>
        <h2 style={styles.sectionTitle}>Travel Categories</h2>
        <div style={styles.scrollContainer}>
          {categories.map((cat, i) => (
            <div key={i} style={styles.card}>
              <img src={cat.image} alt={cat.name} style={styles.cardImage} />
              <div style={styles.cardBody}>
                <h5 style={styles.cardTitle}>{cat.name}</h5>
                <Button 
                  variant="primary" 
                  size="sm"
                  onClick={() => handleCategoryClick(cat.name)}
                >
                  Explore
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== Popular Packages ===== */}
      <section style={{ marginBottom: "60px" }}>
        <h2 style={styles.sectionTitle}>Popular Packages</h2>
        <div style={styles.scrollContainer}>
          {packages.map((pkg, i) => (
            <div key={i} style={styles.card}>
              <img src={pkg.image} alt={pkg.name} style={styles.cardImage} />
              <div style={styles.cardBody}>
                <h5 style={styles.cardTitle}>{pkg.name}</h5>
                <p style={styles.price}>{pkg.price}</p>
                <Button 
                  variant="primary" 
                  size="sm"
                  onClick={() => handlePackageClick(pkg.packageId)}
                >
                  Explore
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== Footer ===== */}
      <footer style={styles.footer}>
        <div>
          <p>© 2025 WanderWay Travels | All rights reserved</p>
          <p>🌍 Instagram | Facebook | Twitter</p>
        </div>
      </footer>
    </div>
  );
};

const styles = {
  container: { textAlign: "center", padding: "20px", backgroundColor: "#f9f9fb" },
  sliderImage: { width: "100%", height: "500px", objectFit: "cover", borderRadius: "10px" },
  sectionTitle: { fontSize: "1.8rem", fontWeight: "600", margin: "20px 0", color: "#333" },
  scrollContainer: {
    display: "flex",
    gap: "20px",
    overflowX: "auto",
    padding: "10px 0",
    scrollBehavior: "smooth",
  },
  card: {
    minWidth: "250px",
    backgroundColor: "#fff",
    borderRadius: "15px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    overflow: "hidden",
    flex: "0 0 auto",
    transition: "transform 0.3s ease",
  },
  cardImage: {
    width: "100%",
    height: "160px",
    objectFit: "cover",
  },
  cardBody: {
    padding: "10px 15px",
  },
  cardTitle: {
    fontSize: "1rem",
    fontWeight: "600",
    color: "#333",
  },
  price: {
    fontSize: "0.9rem",
    color: "#555",
    marginBottom: "8px",
  },
  footer: {
    marginTop: "40px",
    padding: "20px",
    backgroundColor: "#fff",
    borderTop: "1px solid #ddd",
    color: "#555",
  },
};

export default Travel;