// src/components/AuthModal.js
import React, { useState, useEffect } from "react";
import { Modal, Button, Form, InputGroup } from "react-bootstrap";
import { FaEye, FaEyeSlash, FaGoogle, FaApple } from "react-icons/fa";



const AuthModal = ({ show, handleClose, onAuthSuccess, initialMode = "login" }) => {

  const [isLogin, setIsLogin] = useState(initialMode === "login");
  const [emailOrMobile, setEmailOrMobile] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [otp, setOtp] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (show) {
      setIsLogin(initialMode === "login");
      setEmailOrMobile("");
      setPassword("");
      setConfirmPassword("");
      setName("");
      setOtp("");
      setError("");
      setShowPassword(false);
      setShowConfirmPassword(false);
    }
  }, [show, initialMode]);

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setError("");

    const storedEmail = localStorage.getItem("email");
    const storedPassword = localStorage.getItem("password");
    const storedMobile = localStorage.getItem("mobile");

    if (
      emailOrMobile === storedEmail ||
      emailOrMobile === storedMobile
    ) {
      if (password === storedPassword) {
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("userEmail", emailOrMobile);
        window.dispatchEvent(new Event("authChange"));
        handleClose();
        if (onAuthSuccess) onAuthSuccess();
      } else {
        setError("Incorrect password");
      }
    } else {
      setError("User not found");
    }
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();
    setError("");

    if (!name || !emailOrMobile || !password || !confirmPassword) {
      setError("All fields are required");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    // Save signup info (you can extend OTP verification here)
    localStorage.setItem("email", emailOrMobile.includes("@") ? emailOrMobile : "");
    localStorage.setItem("mobile", !emailOrMobile.includes("@") ? emailOrMobile : "");
    localStorage.setItem("password", password);
    localStorage.setItem("userEmail", emailOrMobile);
    handleClose();
    if (onAuthSuccess) onAuthSuccess("login");

    // Clear signup fields
    setName("");
    setEmailOrMobile("");
    setPassword("");
    setConfirmPassword("");
    setOtp("");
    setError("");
  };

  return (
    <Modal show={show} onHide={handleClose} centered size="lg">
      <div className="d-flex" style={{ minHeight: "400px" }}>
        {/* Left Side Image */}
        <div
          className="d-none d-md-flex flex-column justify-content-center align-items-center"
          style={{
            flex: 1,
            backgroundImage:
              "url('https://images.unsplash.com/photo-1607746882042-944635dfe10e?auto=format&fit=crop&w=600&q=80')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            color: "#fff",
            padding: "20px",
          }}
        >
          <h2>Welcome to WanderWay</h2>
          <p>Explore destinations, book flights & hotels easily</p>
        </div>

        {/* Right Side Form */}
        <div style={{ flex: 1, padding: "30px" }}>
          {isLogin ? (
            <>
              <h3 className="mb-3">Login</h3>
              {error && <p style={{ color: "red" }}>{error}</p>}
              <Form onSubmit={handleLoginSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Email or Mobile</Form.Label>
                  <Form.Control
                    type="text"
                    name="email_or_mobile"
                    id="email_or_mobile"
                    value={emailOrMobile}
                    onChange={(e) => setEmailOrMobile(e.target.value)}
                    placeholder="Enter email or mobile"
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter password"
                      required
                    />
                    <Button
                      variant="outline-secondary"
                      onClick={() => setShowPassword(!showPassword)}
                      type="button"
                    >
                      {showPassword ? <FaEyeSlash /> : <FaEye />}
                    </Button>
                  </InputGroup>
                </Form.Group>

                <Button variant="primary" type="submit" className="w-100 mb-2">
                  Login
                </Button>
                <div className="text-end mb-3">
                <button
                    type="button"
                    onClick={() => alert("Implement forgot password flow")}
                    style={{
                        border: "none",
                        background: "none",
                        color: "#007bff",
                        padding: 0,
                        cursor: "pointer",
                    }}
                    >
                    Forgot password?
                </button>

                </div>

                <div className="d-flex justify-content-center gap-2 mb-3">
                  <Button variant="outline-danger" type="button">
                    <FaGoogle /> Google
                  </Button>
                  <Button variant="outline-dark" type="button">
                    <FaApple /> Apple
                  </Button>
                </div>

                <p className="text-center">
                  Don't have an account?{" "}
                  <span
                    style={{ color: "#007bff", cursor: "pointer" }}
                    onClick={() => setIsLogin(false)}
                  >
                    Sign Up
                  </span>
                </p>
              </Form>
            </>
          ) : (
            <>
              <h3 className="mb-3">Sign Up</h3>
              {error && <p style={{ color: "red" }}>{error}</p>}
              <Form onSubmit={handleSignupSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Email or Mobile</Form.Label>
                  <Form.Control
                    type="text"
                    value={emailOrMobile}
                    onChange={(e) => setEmailOrMobile(e.target.value)}
                    placeholder="Enter email or mobile"
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>OTP Verification</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type="text"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      placeholder="Enter OTP"
                      required
                    />
                    <Button variant="outline-secondary" type="button">
                      Send OTP
                    </Button>
                  </InputGroup>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter password"
                      required
                    />
                    <Button
                      variant="outline-secondary"
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <FaEyeSlash /> : <FaEye />}
                    </Button>
                  </InputGroup>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Confirm Password</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm password"
                      required
                    />
                    <Button
                      variant="outline-secondary"
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
                    </Button>
                  </InputGroup>
                </Form.Group>

                <Button variant="primary" type="submit" className="w-100 mb-3">
                  Sign Up
                </Button>

                <p className="text-center">
                  Already have an account?{" "}
                  <span
                    style={{ color: "#007bff", cursor: "pointer" }}
                    onClick={() => setIsLogin(true)}
                  >
                    Login
                  </span>
                </p>
              </Form>
            </>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default AuthModal;
