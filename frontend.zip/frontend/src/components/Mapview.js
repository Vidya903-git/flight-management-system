// src/components/Mapview.js
import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Custom marker icon
const icon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/684/684908.png",
  iconSize: [38, 38],
  iconAnchor: [19, 38],
});

// Locations list
const locations = [
  {
    name: "New York, USA",
    lat: 40.7128,
    lng: -74.006,
    img: "https://images.pexels.com/photos/313782/pexels-photo-313782.jpeg",
  },
  {
    name: "London, UK",
    lat: 51.5074,
    lng: -0.1278,
    img: "https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg",
  },
  {
    name: "Dubai, UAE",
    lat: 25.276987,
    lng: 55.296249,
    img: "https://images.pexels.com/photos/1643417/pexels-photo-1643417.jpeg",
  },
  {
    name: "Tokyo, Japan",
    lat: 35.6762,
    lng: 139.6503,
    img: "https://images.pexels.com/photos/2081187/pexels-photo-2081187.jpeg",
  },
  {
    name: "Bali, Indonesia",
    lat: -8.4095,
    lng: 115.1889,
    img: "https://images.pexels.com/photos/2531234/pexels-photo-2531234.jpeg",
  },
  {
    name: "Sydney, Australia",
    lat: -33.8688,
    lng: 151.2093,
    img: "https://images.pexels.com/photos/2193300/pexels-photo-2193300.jpeg",
  },
];

const Mapview = () => {
  return (
    <div
      style={{
        width: "100%",
        height: "550px",
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0px 4px 15px rgba(0,0,0,0.15)",
      }}
    >
      <MapContainer
        center={[25, 15]}
        zoom={2}
        minZoom={2}
        maxZoom={6}
        style={{ width: "100%", height: "100%" }}
        zoomControl={true}
      >
        {/* Clean & bright world map */}
        <TileLayer
          url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
        />

        {locations.map((loc, index) => (
          <Marker key={index} position={[loc.lat, loc.lng]} icon={icon}>
            <Popup>
              <div
                style={{
                  width: "200px",
                  textAlign: "center",
                  padding: "8px",
                }}
              >
                <img
                  src={loc.img}
                  alt={loc.name}
                  style={{
                    width: "100%",
                    height: "120px",
                    borderRadius: "10px",
                    objectFit: "cover",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                  }}
                />
                <h3
                  style={{
                    margin: "10px 0 5px 0",
                    fontSize: "18px",
                    fontWeight: "700",
                  }}
                >
                  {loc.name}
                </h3>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default Mapview;
