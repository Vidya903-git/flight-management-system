// src/components/Booking.js
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Container, Card, Button, Row, Col, Form } from "react-bootstrap";
import AuthModal from "./AuthModal";
import "bootstrap/dist/css/bootstrap.min.css";

const Booking = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [bookingData, setBookingData] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true); // 👈 new flag to prevent blank render
  const [paymentMethod, setPaymentMethod] = useState("");
  const [cardDetails, setCardDetails] = useState({
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
  });
  const [upiId, setUpiId] = useState("");
  const [walletSelected, setWalletSelected] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";

    if (!isLoggedIn) {
      setShowLogin(true);
      setCheckingAuth(false);
    } else if (location.state) {
      setBookingData(location.state);
      setCheckingAuth(false);
    } else {
      navigate("/home");
    }
  }, [location, navigate]);

  const handleLoginSuccess = () => {
    localStorage.setItem("isLoggedIn", "true");
    setShowLogin(false);
    if (location.state) {
      setBookingData(location.state);
    } else {
      navigate("/home");
    }
  };

  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
    setCardDetails({ cardNumber: "", cardName: "", expiryDate: "", cvv: "" });
    setUpiId("");
    setWalletSelected("");
  };

  const handleCardChange = (e) => {
    const { name, value } = e.target;
    setCardDetails({ ...cardDetails, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!paymentMethod) {
      alert("Please select a payment method!");
      return;
    }

    if (paymentMethod === "card") {
      if (!cardDetails.cardNumber || !cardDetails.cardName || !cardDetails.expiryDate || !cardDetails.cvv) {
        alert("Please fill in all card details!");
        return;
      }
      if (cardDetails.cardNumber.length < 16 || !/^\d+$/.test(cardDetails.cardNumber.replace(/\s/g, ""))) {
        alert("Please enter a valid 16-digit card number!");
        return;
      }
      if (cardDetails.cvv.length !== 3 || !/^\d+$/.test(cardDetails.cvv)) {
        alert("Please enter a valid 3-digit CVV!");
        return;
      }
    } else if (paymentMethod === "upi") {
      if (!upiId || !/^[\w.-]+@[\w]+$/.test(upiId)) {
        alert("Please enter a valid UPI ID!");
        return;
      }
    } else if (paymentMethod === "wallet") {
      if (!walletSelected) {
        alert("Please select a wallet!");
        return;
      }
    }

    alert("Payment processing... Booking confirmed!");

    // Build a single booking object that contains everything
    const bookingConfirmation = {
      // preserve whatever was in bookingData (flight, searchParams, selectedSeat, selectedMeal, seatPrice, mealPrice, passenger)
      ...bookingData,
      // add payment details + ids
      paymentMethod,
      paymentDetails:
        paymentMethod === "card"
          ? cardDetails
          : paymentMethod === "upi"
          ? { upiId }
          : { wallet: walletSelected },
      bookingId: `BK${Date.now()}`,
      bookingDate: new Date().toISOString(),
    };

    // persist for later
    localStorage.setItem("lastBooking", JSON.stringify(bookingConfirmation));

    // IMPORTANT: navigate with the booking object directly (not nested under bookingData)
    navigate("/booking-confirmation", {
      state: bookingConfirmation
    });
  };


  const styles = {
    container: {
      padding: "40px 20px",
      backgroundColor: "#f8f9fa",
      minHeight: "100vh",
    },
    loadingContainer: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundColor: "#f8f9fa",
    },
    title: {
      fontSize: "2rem",
      fontWeight: "600",
      color: "#222",
      marginBottom: "30px",
      textAlign: "center",
    },
    card: {
      border: "none",
      borderRadius: "12px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
      marginBottom: "20px",
    },
    cardHeader: {
      backgroundColor: "#0071eb",
      color: "#fff",
      padding: "15px 20px",
      borderRadius: "12px 12px 0 0",
      fontSize: "1.2rem",
      fontWeight: "600",
    },
    cardBody: {
      padding: "30px",
    },
    paymentMethodCard: {
      border: "2px solid #e9ecef",
      borderRadius: "8px",
      padding: "15px",
      marginBottom: "15px",
      cursor: "pointer",
      transition: "all 0.3s",
    },
    paymentMethodCardActive: {
      border: "2px solid #0071eb",
      backgroundColor: "#e7f0ff",
    },
    submitButton: {
      backgroundColor: "#28a745",
      border: "none",
      padding: "15px 40px",
      borderRadius: "8px",
      color: "white",
      fontWeight: "600",
      fontSize: "1.1rem",
      cursor: "pointer",
      width: "100%",
      marginTop: "20px",
    },
  };

  // 👇 Prevent blank screen while checking login
  if (checkingAuth) {
    return (
      <div style={styles.loadingContainer}>
        <p>Checking login...</p>
      </div>
    );
  }

  // 👇 Show login modal when needed
  if (showLogin) {
    return (
      <AuthModal
        show={true}
        handleClose={() => navigate("/home")}
        defaultMode="login"
        onSuccess={handleLoginSuccess}
      />
    );
  }

  // 👇 Show loading if booking data not found
  if (!bookingData) {
    return (
      <div style={styles.loadingContainer}>
        <p>Loading booking details...</p>
      </div>
    );
  }

  const {   flight,
    searchParams,
    selectedSeat,
    selectedMeal,
    seatPrice,
    mealPrice } = bookingData;
  const totalPrice =
  flight?.price +
  (seatPrice || 0) +
  (mealPrice || 0);


  return (
    <div style={styles.container}>
      <Container>
        <h2 style={styles.title}>Complete Your Booking</h2>

        <Row>
          {/* Left Column */}
          <Col md={8}>
            {/* Flight Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>✈️ Flight Details</div>
              <div style={styles.cardBody}>
                <p>
                  <strong>{searchParams.from}</strong> → <strong>{searchParams.to}</strong>
                </p>
                <p>Airline: {flight.airline}</p>
                <p>Class: {flight.class}</p>
                <p>Departure: {searchParams.departDate}</p>
                {selectedSeat && (
                  <p className="mt-2">
                    <strong>Seat Selected:</strong> {selectedSeat} 
                    {seatPrice > 0 && ` (₹${seatPrice})`}
                  </p>
                )}

                {selectedMeal && (
                  <p>
                    <strong>Meal Selected:</strong> {selectedMeal}
                    {mealPrice > 0 && ` (₹${mealPrice})`}
                  </p>
                )}
                </div>
            </Card>

            {/* Payment */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>💳 Payment</div>
              <div style={styles.cardBody}>
                <div
                  style={{
                    ...styles.paymentMethodCard,
                    ...(paymentMethod === "card" ? styles.paymentMethodCardActive : {}),
                  }}
                  onClick={() => handlePaymentMethodChange("card")}
                >
                  💳 Credit / Debit Card
                </div>

                {paymentMethod === "card" && (
                  <>
                    <Form.Group className="mb-3">
                      <Form.Label>Card Number</Form.Label>
                      <Form.Control
                        type="text"
                        name="cardNumber"
                        value={cardDetails.cardNumber}
                        onChange={handleCardChange}
                        placeholder="1234 5678 9012 3456"
                        maxLength="19"
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Cardholder Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="cardName"
                        value={cardDetails.cardName}
                        onChange={handleCardChange}
                        placeholder="Name on card"
                      />
                    </Form.Group>
                  </>
                )}

                <div
                  style={{
                    ...styles.paymentMethodCard,
                    ...(paymentMethod === "upi" ? styles.paymentMethodCardActive : {}),
                  }}
                  onClick={() => handlePaymentMethodChange("upi")}
                >
                  📱 UPI
                </div>

                {paymentMethod === "upi" && (
                  <Form.Group className="mb-3">
                    <Form.Label>UPI ID</Form.Label>
                    <Form.Control
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="yourname@paytm"
                    />
                  </Form.Group>
                )}

                <Button onClick={handleSubmit} style={styles.submitButton}>
                  Confirm & Pay
                </Button>
              </div>
            </Card>
          </Col>

          {/* Right Column */}
          <Col md={4}>
            <Card style={styles.card}>
              <div style={styles.cardHeader}>💰 Price Summary</div>
              <div style={styles.cardBody}>
                <p>Total Price: ₹{totalPrice.toLocaleString()}</p>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Booking;
