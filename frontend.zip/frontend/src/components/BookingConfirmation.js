// src/components/BookingConfirmation.js
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Container, Card, Button, Row, Col } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";


const BookingConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [bookingData, setBookingData] = useState(null);

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    if (!isLoggedIn) {
      navigate("/login");
      return;
    }

    // Get booking data from location state or localStorage
    if (location.state) {
      setBookingData(location.state);
      // Also save to localStorage for persistence
      localStorage.setItem("lastBooking", JSON.stringify(location.state));
    } else {
      // Try to get from localStorage
      const savedBooking = localStorage.getItem("lastBooking");
      if (savedBooking) {
        setBookingData(JSON.parse(savedBooking));
      } else {
        // If no data, redirect to home
        navigate("/home");
      }
    }
  }, [location, navigate]);

  const handleDownloadTicket = () => {
    alert("Ticket download feature will be available soon!");
    // In a real app, this would generate and download a PDF ticket
  };

  const handlePrintTicket = () => {
    window.print();
  };

  // Define styles before early return
  const styles = {
    container: {
      padding: "40px 20px",
      backgroundColor: "#f8f9fa",
      minHeight: "100vh",
    },
    loadingContainer: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundColor: "#f8f9fa",
    },
    successBanner: {
      backgroundColor: "#28a745",
      color: "#fff",
      padding: "30px",
      borderRadius: "12px",
      marginBottom: "30px",
      textAlign: "center",
    },
    successIcon: {
      fontSize: "4rem",
      marginBottom: "15px",
    },
    successTitle: {
      fontSize: "2rem",
      fontWeight: "600",
      marginBottom: "10px",
    },
    successMessage: {
      fontSize: "1.1rem",
      opacity: 0.9,
    },
    bookingId: {
      fontSize: "1.5rem",
      fontWeight: "700",
      backgroundColor: "rgba(255,255,255,0.2)",
      padding: "10px 20px",
      borderRadius: "8px",
      display: "inline-block",
      marginTop: "15px",
    },
    card: {
      border: "none",
      borderRadius: "12px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
      marginBottom: "20px",
    },
    cardHeader: {
      backgroundColor: "#0071eb",
      color: "#fff",
      padding: "15px 20px",
      borderRadius: "12px 12px 0 0",
      fontSize: "1.2rem",
      fontWeight: "600",
    },
    cardBody: {
      padding: "30px",
    },
    sectionTitle: {
      fontSize: "1.3rem",
      fontWeight: "600",
      color: "#333",
      marginBottom: "15px",
      borderBottom: "2px solid #e9ecef",
      paddingBottom: "10px",
    },
    infoRow: {
      display: "flex",
      justifyContent: "space-between",
      padding: "12px 0",
      borderBottom: "1px solid #f0f0f0",
    },
    infoLabel: {
      fontWeight: "500",
      color: "#666",
      fontSize: "0.95rem",
    },
    infoValue: {
      fontWeight: "600",
      color: "#222",
      fontSize: "0.95rem",
    },
    qrCode: {
      width: "150px",
      height: "150px",
      backgroundColor: "#f0f0f0",
      border: "2px solid #ddd",
      borderRadius: "8px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "20px auto",
      fontSize: "0.9rem",
      color: "#666",
    },
    actionButtons: {
      display: "flex",
      gap: "15px",
      marginTop: "30px",
      justifyContent: "center",
    },
    button: {
      padding: "12px 30px",
      borderRadius: "8px",
      border: "none",
      fontWeight: "600",
      fontSize: "1rem",
      cursor: "pointer",
      transition: "0.3s",
    },
    downloadButton: {
      backgroundColor: "#0071eb",
      color: "#fff",
    },
    printButton: {
      backgroundColor: "#6c757d",
      color: "#fff",
    },
    homeButton: {
      backgroundColor: "#28a745",
      color: "#fff",
    },
    importantInfo: {
      backgroundColor: "#fff3cd",
      border: "1px solid #ffc107",
      borderRadius: "8px",
      padding: "20px",
      marginTop: "20px",
    },
    importantTitle: {
      fontWeight: "600",
      color: "#856404",
      marginBottom: "10px",
      fontSize: "1.1rem",
    },
    importantText: {
      color: "#856404",
      fontSize: "0.95rem",
      lineHeight: "1.6",
    },
  };

  if (!bookingData) {
    return (
      <div style={styles.loadingContainer}>
        <p>Loading booking confirmation...</p>
      </div>
    );
  }
  // Extract values safely
const {
  flight = {},
  searchParams = {},
  passenger = {},
  paymentMethod,
  bookingId,
  selectedSeat = null,
  selectedMeal = null,
  seatPrice = 0,
  mealPrice = 0,
  bookingDate
} = bookingData;

// Safe price handling
const baseFare = flight?.price || 0;
const seatFare = seatPrice || 0;
const mealFare = mealPrice || 0;

const totalPrice =
  baseFare * (searchParams?.passengers || 1) +
  seatFare +
  mealFare;

const formattedDate = bookingDate
  ? new Date(bookingDate).toLocaleString()
  : new Date().toLocaleString();

  const handleGoToDashboard = () => {
    const booking = {
      type: "flight",
      bookingId: bookingId || `BK${Date.now()}`,
      route: `${searchParams.from} → ${searchParams.to}`,
      airline: flight.airline,
      departDate: searchParams.departDate,
      returnDate: searchParams.returnDate || null,
      passengers: searchParams.passengers || 1,
      amount: totalPrice,
      bookingDate: formattedDate
    };
  
    // Save to localStorage
    const existing = JSON.parse(localStorage.getItem("flightBookings") || "[]");
    const updated = [...existing, booking];
    localStorage.setItem("flightBookings", JSON.stringify(updated));
  
    // Navigate to dashboard
    navigate("/dashboard", {
      state: {
        page: "bookings",
        bookingType: "flight",
        bookingData: booking,
      }
    });
  };

  return (
    <div style={styles.container}>
      <Container>
        {/* Success Banner */}
        <div style={styles.successBanner}>
          <div style={styles.successIcon}>✅</div>
          <h2 style={styles.successTitle}>Booking Confirmed!</h2>
          <p style={styles.successMessage}>
            Your flight has been successfully booked. A confirmation email has been sent to your registered email address.
          </p>
          <div style={styles.bookingId}>
            Booking ID: {bookingId || `BK${Date.now()}`}
          </div>
        </div>

        <Row>
          {/* Left Column: Booking Details */}
          <Col md={8}>
            {/* Flight Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>✈️ Flight Details</div>
              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Journey Information</div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Route:</span>
                  <span style={styles.infoValue}>
                    {searchParams.from} → {searchParams.to}
                  </span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Airline:</span>
                  <span style={styles.infoValue}>{flight.airline}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Flight Class:</span>
                  <span style={styles.infoValue}>{flight.class}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Departure Date:</span>
                  <span style={styles.infoValue}>{searchParams.departDate}</span>
                </div>
                {searchParams.returnDate && (
                  <div style={styles.infoRow}>
                    <span style={styles.infoLabel}>Return Date:</span>
                    <span style={styles.infoValue}>{searchParams.returnDate}</span>
                  </div>
                )}
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Duration:</span>
                  <span style={styles.infoValue}>{flight.duration}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Stops:</span>
                  <span style={styles.infoValue}>{flight.stops}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Number of Passengers:</span>
                  <span style={styles.infoValue}>{searchParams.passengers || 1}</span>
                </div>
                {selectedSeat && (
                  <p className="mt-2">
                    <strong>Seat Selected:</strong> {selectedSeat} 
                    {seatPrice > 0 && ` (₹${seatPrice})`}
                  </p>
                )}

                {selectedMeal && (
                  <p>
                    <strong>Meal Selected:</strong> {selectedMeal}
                    {mealPrice > 0 && ` (₹${mealPrice})`}
                  </p>
                )}

              </div>
            </Card>

            {/* Passenger Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>👤 Passenger Details</div>
              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Passenger Information</div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Name:</span>
                  <span style={styles.infoValue}>{passenger.passengerName}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Age:</span>
                  <span style={styles.infoValue}>{passenger.age} years</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Gender:</span>
                  <span style={styles.infoValue}>{passenger.gender}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Mobile:</span>
                  <span style={styles.infoValue}>{passenger.mobile || "N/A"}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Email:</span>
                  <span style={styles.infoValue}>{passenger.email || "N/A"}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>ID Proof:</span>
                  <span style={styles.infoValue}>
                    {passenger.idProofType} - {passenger.idProofNumber}
                  </span>
                </div>
              </div>
            </Card>

            {/* Payment Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>💳 Payment Details</div>
              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Payment Information</div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Payment Method:</span>
                  <span style={styles.infoValue}>
                    {paymentMethod === "card" ? "Credit/Debit Card" :
                     paymentMethod === "upi" ? "UPI" :
                     paymentMethod === "wallet" ? "Digital Wallet" :
                     paymentMethod === "netbanking" ? "Net Banking" : paymentMethod}
                  </span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Total Amount Paid:</span>
                  <span style={styles.infoValue}>₹{totalPrice.toLocaleString()}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Payment Status:</span>
                  <span style={{ ...styles.infoValue, color: "#28a745" }}>✅ Paid</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Booking Date & Time:</span>
                  <span style={styles.infoValue}>{formattedDate}</span>
                </div>
              </div>
            </Card>

            {/* Important Information */}
            <div style={styles.importantInfo}>
              <div style={styles.importantTitle}>📋 Important Information</div>
              <div style={styles.importantText}>
                <p><strong>• Check-in:</strong> Please arrive at the airport at least 2 hours before departure for domestic flights and 3 hours for international flights.</p>
                <p><strong>• Required Documents:</strong> Please carry a valid ID proof (as provided during booking) and your booking confirmation.</p>
                <p><strong>• Cancellation:</strong> Cancellation and refund policies vary by airline. Please check the airline's terms and conditions.</p>
                <p><strong>• Contact:</strong> For any queries, contact our customer support at support@wanderway.com or call +91-1800-XXX-XXXX.</p>
              </div>
            </div>
          </Col>

          {/* Right Column: Booking Summary & QR Code */}
          <Col md={4}>
            <Card style={styles.card}>
              <div style={styles.cardHeader}>📄 Booking Summary</div>
              <div style={styles.actionButtons}>
                <Button
                  onClick={handleGoToDashboard}
                  style={{ ...styles.button, backgroundColor: "#007bff", color: "#fff" }}
                >
                  📘 View in My Bookings
                </Button>
              </div>

              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Quick Reference</div>
                
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Booking ID:</span>
                  <span style={styles.infoValue}>{bookingId || `BK${Date.now()}`}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Passenger:</span>
                  <span style={styles.infoValue}>{passenger.passengerName}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Route:</span>
                  <span style={styles.infoValue}>
                    {searchParams.from} → {searchParams.to}
                  </span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Date:</span>
                  <span style={styles.infoValue}>{searchParams.departDate}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Total Amount:</span>
                  <span style={{ ...styles.infoValue, color: "#28a745", fontSize: "1.1rem" }}>
                    ₹{totalPrice.toLocaleString()}
                  </span>
                </div>
                

                {/* QR Code Placeholder */}
                <div style={styles.qrCode}>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: "2rem", marginBottom: "5px" }}>📱</div>
                    <div>QR Code</div>
                    <div style={{ fontSize: "0.8rem", marginTop: "5px" }}>
                      {bookingId || `BK${Date.now()}`}
                    </div>
                  </div>
                </div>
                <p style={{ textAlign: "center", fontSize: "0.85rem", color: "#666", marginTop: "10px" }}>
                  Show this QR code at the airport for quick check-in
                </p>
              </div>
            </Card>

            {/* Action Buttons */}
            <div style={styles.actionButtons}>
              <Button
                onClick={handleDownloadTicket}
                style={{ ...styles.button, ...styles.downloadButton }}
              >
                📥 Download Ticket
              </Button>
            </div>
            <div style={styles.actionButtons}>
              <Button
                onClick={handlePrintTicket}
                style={{ ...styles.button, ...styles.printButton }}
              >
                🖨️ Print Ticket
              </Button>
            </div>
            <div style={styles.actionButtons}>
              <Button
                onClick={() => navigate("/home")}
                style={{ ...styles.button, ...styles.homeButton }}
              >
                🏠 Back to Home
              </Button>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default BookingConfirmation;

