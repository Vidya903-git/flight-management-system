// src/pages/About.js
import React from "react";
import { Carousel } from "react-bootstrap";

const About = () => {
  return (
    <div style={{ background: "#f8f9fa", padding: "30px 20px" }}>
    <Carousel
        fade
        interval={3000}
        style={{
        marginBottom: "40px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        }}
    >
        <Carousel.Item>
        <div style={{ display: "flex", justifyContent: "center" }}>
            <img
            src="https://static0.simpleflyingimages.com/wordpress/wp-content/uploads/2023/06/shutterstock_2056218710-2.jpg"
            alt="slide1"
            style={{
                width: "100%",
                maxWidth: "700px",
                height: "400px",
                objectFit: "cover",
                borderRadius: "10px",
            }}
            />
        </div>
        <Carousel.Caption>
            <h3>Explore the Best Flight Deals</h3>
            <p>Find the best flight deals with WanderWay Travels</p>
        </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item>
        <div style={{ display: "flex", justifyContent: "center" }}>
            <img
            src="https://media.istockphoto.com/id/516449022/photo/lady-with-kayak.jpg?s=612x612&w=0&k=20&c=Yp-rzpmY_hbhpbTE38z6toouRKW-lAEN-ZvuWvH8kKE="
            alt="slide2"
            style={{
                width: "100%",
                maxWidth: "700px",
                height: "400px",
                objectFit: "cover",
                borderRadius: "10px",
            }}
            />
        </div>
        <Carousel.Caption>
            <h3>See the world with Wander Way Travels</h3>
            <p>Explore the world with the best package of Wander Way Travels</p>
        </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item>
        <div style={{ display: "flex", justifyContent: "center" }}>
            <img
            src="https://media.istockphoto.com/id/904172104/photo/weve-made-it-all-this-way-i-am-proud.jpg?s=612x612&w=0&k=20&c=MewnsAhbeGRcMBN9_ZKhThmqPK6c8nCT8XYk5ZM_hdg="
            alt="slide3"
            style={{
                width: "100%",
                maxWidth: "700px",
                height: "400px",
                objectFit: "cover",
                borderRadius: "10px",
            }}
            />
        </div>
        <Carousel.Caption>
            <h3>Adventure is waiting for you</h3>
            <p>
            Enjoy your journey with friends and family by the package of Wander
            Way Travels
            </p>
        </Carousel.Caption>
        </Carousel.Item>
    </Carousel>
      <div style={{ maxWidth: "1100px", margin: "auto" }}>
        {/* Header */}
        <h1
          style={{
            fontSize: "40px",
            fontWeight: "800",
            textAlign: "center",
            marginBottom: "20px",
          }}
        >
          About Wander Way Travels
        </h1>

        <p
          style={{
            textAlign: "center",
            maxWidth: "800px",
            margin: "auto",
            fontSize: "18px",
            color: "#555",
            lineHeight: "1.7",
          }}
        >
          Wander Way Travels is a trusted travel company offering the best flight
          booking services and customized tour packages across the globe. With a
          strong network of airlines, hotels, and travel partners, we ensure a
          seamless travel experience from planning to return.
        </p>

        {/* Section 1 */}
        <div
          style={{
            marginTop: "50px",
            display: "flex",
            gap: "40px",
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          <div style={{ flex: 1, minWidth: "300px" }}>
            <h2 style={{ fontSize: "28px", fontWeight: "700" }}>
              Who We Are
            </h2>
            <p style={{ fontSize: "17px", color: "#444", lineHeight: "1.7" }}>
              We are a passionate team of travel experts dedicated to making
              journeys simple, affordable, and memorable. Whether you want the
              best flight deals or a perfectly planned vacation, Wander Way
              provides tailored solutions that prioritize comfort and value.
            </p>
          </div>

          <div style={{ flex: 1, minWidth: "300px" }}>
            <img
              src="https://img.freepik.com/premium-photo/travel-traveling-symbolic-picture-vacation-background-15_1032298-2376.jpg?semt=ais_hybrid&w=740&q=80"
              alt="Travel"
              style={{
                width: "100%",
                borderRadius: "15px",
                boxShadow: "0px 4px 12px rgba(0,0,0,0.15)",
              }}
            />
          </div>
        </div>

        {/* Section 2 — Services */}
        <h2
          style={{
            fontSize: "32px",
            fontWeight: "700",
            marginTop: "60px",
            textAlign: "center",
          }}
        >
          What We Offer
        </h2>

        <div
          style={{
            marginTop: "30px",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "25px",
          }}
        >
          {[
            {
              title: "Flight Bookings",
              desc: "Best deals on domestic & international flights with instant confirmations.",
            },
            {
              title: "Tour Packages",
              desc: "Customised holiday packages for families, couples, solo travellers & groups.",
            },
            {
              title: "24/7 Customer Support",
              desc: "Dedicated support to assist you anytime during your journey.",
            },
          ].map((item, i) => (
            <div
              key={i}
              style={{
                background: "#fff",
                padding: "25px",
                borderRadius: "15px",
                boxShadow: "0px 4px 12px rgba(0,0,0,0.1)",
              }}
            >
              <h3 style={{ fontSize: "22px", fontWeight: "600" }}>{item.title}</h3>
              <p style={{ fontSize: "16px", color: "#666", marginTop: "10px" }}>
                {item.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Mission */}
        <div style={{ marginTop: "60px", textAlign: "center" }}>
          <h2 style={{ fontSize: "30px", fontWeight: "700" }}>Our Mission</h2>
          <p
            style={{
              fontSize: "18px",
              maxWidth: "800px",
              margin: "20px auto",
              color: "#444",
              lineHeight: "1.7",
            }}
          >
            Our mission is to make travel accessible, reliable, and enjoyable.
            We aim to provide transparency, trust, and top-notch service at
            every step of the journey.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
