// src/components/SeatFoodSelection.js
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const SeatFoodSelection = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const { flight, searchParams, passenger } = location.state || {};

  // flight.type comes from PassengerDetails (domestic / international)
  const flightType = flight?.type || "domestic";

  // ------------------- STATES ---------------------
  const [seatPopup, setSeatPopup] = useState(false);
  const [mealPopup, setMealPopup] = useState(false);
  const [mealCategory, setMealCategory] = useState(null);

  const [selectedSeat, setSelectedSeat] = useState(null);
  const [selectedMeal, setSelectedMeal] = useState(null);
  const [selectedMealPrice, setSelectedMealPrice] = useState(0);

  // ------------------- DOMESTIC VS INTERNATIONAL SEATS -----------------------
  let totalRows = flightType === "international" ? 30 : 20; // domestic = 20 rows, international = 30 rows

  const seats = [];
  for (let row = 1; row <= totalRows; row++) {
    ["A", "B", "C", "D", "E", "F"].forEach((col) => seats.push(col + row));
  }

  // Seat pricing
  const seatPrice = selectedSeat
    ? flightType === "international"
      ? 500 + (selectedSeat.charCodeAt(0) - 65) * 70 // higher pricing for international
      : 300 + (selectedSeat.charCodeAt(0) - 65) * 50
    : 0;

  // ------------------- DOMESTIC & INTERNATIONAL MEALS -----------------------
  const meals = {
    domestic: {
      nonveg: [
        { name: "Chicken Biryani", price: 180 },
        { name: "Grilled Chicken Meal", price: 220 },
      ],
      veg: [
        { name: "Veg Biryani", price: 150 },
        { name: "Paneer Butter Masala + Naan", price: 200 },
      ],
      pasta: [
        { name: "White Sauce Pasta", price: 160 },
        { name: "Red Sauce Pasta", price: 150 },
      ],
    },

    international: {
      nonveg: [
        { name: "Chicken Steak Meal", price: 350 },
        { name: "Fish Fillet Meal", price: 380 },
        { name: "Chicken Curry + Rice", price: 320 },
      ],
      veg: [
        { name: "Veg Lasagna", price: 300 },
        { name: "Stir Fried Veg + Rice", price: 280 },
        { name: "Paneer Combo Meal", price: 320 },
      ],
      pasta: [
        { name: "Creamy Alfredo Pasta", price: 280 },
        { name: "Chicken Pasta", price: 300 },
      ],
    },
  };

  const selectedMeals = meals[flightType];

  // ------------------- CONTINUE -------------------
  const handleContinue = () => {
    if (!selectedSeat) return alert("Please select a seat.");
    if (!selectedMeal) return alert("Please select a meal.");

    navigate("/booking", {
      state: {
        flight,
        searchParams,
        passenger,
        selectedSeat,
        seatPrice,
        selectedMeal,
        mealPrice: selectedMealPrice,
      },
    });
  };

  // ------------------- INLINE STYLES (unchanged) -------------------
  const styles = {
    wrapper: {
      padding: "40px",
      display: "flex",
      justifyContent: "space-between",
      gap: "30px",
    },
    card: {
      padding: "20px",
      background: "#fff",
      borderRadius: "12px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
      width: "48%",
    },
    airplaneImg: {
      width: "100%",
      borderRadius: "12px",
      cursor: "pointer",
      transition: "0.3s",
    },
    mealBox: {
      padding: "15px",
      background: "#f7f7f7",
      borderRadius: "10px",
      marginBottom: "15px",
      cursor: "pointer",
    },
    popupOverlay: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "rgba(0,0,0,0.5)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 2000,
    },
    popupBox: {
      width: "500px",
      maxHeight: "75vh",
      overflowY: "auto",
      background: "#fff",
      borderRadius: "12px",
      padding: "20px",
    },
    seatBtn: (active) => ({
      padding: "10px",
      background: active ? "#007bff" : "#eee",
      color: active ? "white" : "black",
      borderRadius: "6px",
      border: "none",
      cursor: "pointer",
    }),
    mealItem: {
      padding: "12px",
      borderBottom: "1px solid #ddd",
      cursor: "pointer",
    },
    continueBtn: {
      marginTop: "20px",
      padding: "16px",
      background: "#007bff",
      color: "#fff",
      border: "none",
      borderRadius: "8px",
      width: "100%",
      fontSize: "18px",
    },
  };

  // ------------------------------------------------------------------

  return (
    <div style={styles.wrapper}>

      {/* LEFT SECTION — SEAT */}
      <div style={styles.card}>
        <h2>
          Choose Your Seat ({flightType === "international" ? "International" : "Domestic"})
        </h2>

        <img
          src="https://media.springairlines.com/style/site-inter/img/help/ChooseSeatPlane.gif"
          alt="Plane"
          style={styles.airplaneImg}
          onClick={() => setSeatPopup(true)}
        />

        {selectedSeat && (
          <p>
            Seat Selected: <strong>{selectedSeat}</strong> (₹{seatPrice})
          </p>
        )}
      </div>

      {/* RIGHT SECTION — MEAL */}
      <div style={styles.card}>
        <h2>
          Select Your Meal ({flightType === "international" ? "International" : "Domestic"})
        </h2>

        <div style={styles.mealBox} onClick={() => { setMealCategory("nonveg"); setMealPopup(true); }}>
          🍗 Non-Veg Meals
        </div>
        <div style={styles.mealBox} onClick={() => { setMealCategory("veg"); setMealPopup(true); }}>
          🥦 Veg Meals
        </div>
        <div style={styles.mealBox} onClick={() => { setMealCategory("pasta"); setMealPopup(true); }}>
          🍝 Pasta Meals
        </div>

        {selectedMeal && (
          <p>
            Meal Selected: <strong>{selectedMeal}</strong> (₹{selectedMealPrice})
          </p>
        )}

        <button style={styles.continueBtn} onClick={handleContinue}>
          Continue to Booking
        </button>
      </div>

      {/* ---------------- SEAT POPUP ---------------- */}
      {seatPopup && (
        <div style={styles.popupOverlay} onClick={() => setSeatPopup(false)}>
          <div style={styles.popupBox} onClick={(e) => e.stopPropagation()}>
            <h3>Select Seat</h3>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(6, 1fr)",
                gap: "10px",
                paddingTop: "10px",
              }}
            >
              {seats.map((seat) => (
                <button
                  key={seat}
                  style={styles.seatBtn(selectedSeat === seat)}
                  onClick={() => {
                    setSelectedSeat(seat);
                    setSeatPopup(false);
                  }}
                >
                  {seat}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- MEAL POPUP ---------------- */}
      {mealPopup && (
        <div style={styles.popupOverlay} onClick={() => setMealPopup(false)}>
          <div style={styles.popupBox} onClick={(e) => e.stopPropagation()}>
            <h3>
              Select {mealCategory.toUpperCase()} Meal ({flightType})
            </h3>

            {selectedMeals[mealCategory].map((item) => (
              <div
                key={item.name}
                style={styles.mealItem}
                onClick={() => {
                  setSelectedMeal(item.name);
                  setSelectedMealPrice(item.price);
                  setMealPopup(false);
                }}
              >
                <strong>{item.name}</strong> — ₹{item.price}
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

export default SeatFoodSelection;
