// src/components/Navbar.js
import React from "react";
import { NavLink } from "react-router-dom";

const Navbar = () => {
  return (
    <nav style={styles.navbar}>
      <ul style={styles.navList}>
        <li style={{border: "2px solid #fff", borderRadius: "10px", padding: "5px 5px"}}>
          <NavLink to="/home" style={styles.link} activeclassName="active">
            Home
          </NavLink>
        </li>
        <li style={{border: "2px solid #fff", borderRadius: "10px", padding: "5px 5px"}}>
          <NavLink to="/travel" style={styles.link} activeclassname="active">
            Tours
          </NavLink>
        </li>
        <li style={{border: "2px solid #fff", borderRadius: "10px", padding: "5px 5px"}}>
          <NavLink to="/packages" style={styles.link} activeclassname="active">
            Packages
          </NavLink>
        </li>
        <li style={{border: "2px solid #fff", borderRadius: "10px", padding: "5px 5px"}}>
          <NavLink to="/about" style={styles.link} activeclassname="active">
            About
          </NavLink>
        </li>
        <li style={{border: "2px solid #fff", borderRadius: "10px", padding: "5px 5px"}}>
          <NavLink to="/contact" style={styles.link} activeclassname="active">
            Contact
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};

const styles = {
  navbar: {
    position: "sticky",
    top: 70,
    zIndex: 1000,
    backgroundColor: "rgb(131, 91, 249)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "50px",
    boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
  },
  navList: {
    listStyle: "none",
    display: "flex",
    gap: "30px",
    margin: 0,
    padding: 0,
  },
  link: {
    color: "#fff",
    textDecoration: "none",
    fontWeight: "500",
    fontSize: "1rem",
    transition: "0.3s",
  },
  active: {
    borderBottom: "2px solid #fff",
  },
};

export default Navbar;