// src/components/Header.js
import React, { useEffect, useState } from "react";
import { Button, Dropdown } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { FaMapMarkerAlt } from "react-icons/fa";
import AuthModal from "./AuthModal";
import "bootstrap/dist/css/bootstrap.min.css";

const Header = () => {
  const navigate = useNavigate();

  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState(
    localStorage.getItem("isLoggedIn") === "true"
  );
  const [userEmail, setUserEmail] = useState(
    localStorage.getItem("userEmail") || localStorage.getItem("email") || ""
  );

  // Modal control
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState("login"); // "login" | "signup"

  // Sync login/logout state across components
  useEffect(() => {
    const syncAuthState = () => {
      setIsLoggedIn(localStorage.getItem("isLoggedIn") === "true");
      setUserEmail(localStorage.getItem("userEmail") || localStorage.getItem("email") || "");
    };

    syncAuthState();
    window.addEventListener("authChange", syncAuthState);
    return () => window.removeEventListener("authChange", syncAuthState);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("userEmail");
    window.dispatchEvent(new Event("authChange"));
  };

  return (
    <>
      <header style={styles.header}>
        {/* Left: Logo + Name */}
        <div style={styles.left}>
          <img
            src="https://cdn-icons-png.flaticon.com/512/201/201623.png"
            alt="logo"
            style={{ width: "45px", marginRight: "10px" }}
          />
          <h2 style={{ margin: 0, color: "#007bff" }}>WanderWay</h2>
        </div>

        {/* Right: Map + Auth Buttons */}
        <div style={styles.right}>
          <FaMapMarkerAlt
            size={25}
            color="#007bff"
            style={{ cursor: "pointer", marginRight: "20px" }}
            onClick={() => navigate("/mapview")}
          />

          {isLoggedIn ? (
            <Dropdown align="end">
              <Dropdown.Toggle
                style={styles.profileBadge}
                id="dropdown-basic"
              >
                {userEmail ? userEmail.charAt(0).toUpperCase() : "U"}
              </Dropdown.Toggle>

              <Dropdown.Menu style={{ zIndex: 2000 }}>
                <Dropdown.Item onClick={() => navigate("/dashboard")}>
                  Dashboard
                </Dropdown.Item>
                <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          ) : (
            <>
              <Button
                variant="outline-primary"
                size="sm"
                onClick={() => {
                  setAuthMode("login");
                  setShowAuthModal(true);
                }}
                style={{ marginRight: "10px" }}
              >
                Login
              </Button>

              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  setAuthMode("signup");
                  setShowAuthModal(true);
                }}
              >
                Signup
              </Button>
            </>
          )}
        </div>
      </header>

      {/* Auth Modal Component */}
      <AuthModal
        show={showAuthModal}
        handleClose={() => setShowAuthModal(false)}
        initialMode={authMode}
        onAuthSuccess={(mode) => {
          if (mode === "login") {
            setAuthMode("login");       // Switch modal to login
            setShowAuthModal(true);     // Reopen modal
          } else {
            // Any other actions after login (optional)
            setIsLoggedIn(true);
            setUserEmail(localStorage.getItem("userEmail"));
          }
        }}
      />

    </>
  );
};

// ======= Styles =======
const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: "10px 30px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
    position: "sticky",
    top: 0,
    zIndex: 2000,
  },
  left: { display: "flex", alignItems: "center" },
  right: { display: "flex", alignItems: "center", gap: "10px" },
  profileBadge: {
    width: "36px",
    height: "36px",
    borderRadius: "50%",
    backgroundColor: "#e9f2ff",
    color: "#007bff",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontWeight: "bold",
    fontSize: "16px",
    textTransform: "uppercase",
    border: "none",
  },
};

export default Header;
