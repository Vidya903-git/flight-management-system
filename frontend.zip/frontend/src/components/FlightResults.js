// src/components/FlightResults.js
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Container, Row, Col, Card, Button, Form, Badge } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import AuthModal from "./AuthModal"; // make sure this is imported at the top

// Sample default search params
const DEFAULT_SEARCH_PARAMS = {
  from: "Origin",
  to: "Destination",
  travelClass: "Economy",
};

const FlightResults = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const actualSearchParams = location.state?.searchParams || location.state;
  const searchParams = actualSearchParams || DEFAULT_SEARCH_PARAMS;

  const [flights, setFlights] = useState([]);
  const [sortBy, setSortBy] = useState("");
  const [stopFilter, setStopFilter] = useState("All");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [pendingFlight, setPendingFlight] = useState(null);

  const detectFlightType = (from, to) => {
    const indianCities = ["Delhi", "Mumbai", "Chennai", "Bangalore", "Hyderabad", "Kolkata", "Goa", "Ahmedabad", "Jaipur", "Pune", "Cochin", "Lucknow", "Trivandrum"];
    const isFromIndia = indianCities.some((c) => from?.toLowerCase().includes(c.toLowerCase()));
    const isToIndia = indianCities.some((c) => to?.toLowerCase().includes(c.toLowerCase()));
    return isFromIndia && isToIndia ? "Domestic" : "International";
  };

  const generateFlights = useCallback(() => {
    if (!actualSearchParams?.from || !actualSearchParams?.to) {
      setFlights([]);
      return;
    }

    const type = detectFlightType(actualSearchParams.from, actualSearchParams.to);
    const airlines = ["IndiGo", "Air India", "Vistara", "SpiceJet", "Emirates", "Qatar Airways", "Etihad", "Singapore Airlines", "British Airways", "Lufthansa"];

    const flightsData = Array.from({ length: 10 }, (_, i) => {
      const randomStops = Math.floor(Math.random() * 3);
      const randomDuration = 90 + Math.floor(Math.random() * 400);
      const randomPrice = type === "Domestic" ? 4000 + Math.floor(Math.random() * 7000) : 20000 + Math.floor(Math.random() * 60000);
      const randomAirline = airlines[Math.floor(Math.random() * airlines.length)];

      return {
        id: i + 1,
        airline: randomAirline,
        stops: randomStops,
        duration: randomDuration,
        price: randomPrice,
        class: actualSearchParams.travelClass || "Economy",
        type,
      };
    });

    setFlights(flightsData);
  }, [actualSearchParams]);

  useEffect(() => {
    generateFlights();
  }, [generateFlights]);

  // Sorting
  const handleSortChange = (e) => {
    const sortOption = e.target.value;
    setSortBy(sortOption);
    let sorted = [...flights];
    if (sortOption === "price-low-high") sorted.sort((a, b) => a.price - b.price);
    else if (sortOption === "price-high-low") sorted.sort((a, b) => b.price - a.price);
    else if (sortOption === "duration") sorted.sort((a, b) => a.duration - b.duration);
    else if (sortOption === "airline") sorted.sort((a, b) => a.airline.localeCompare(b.airline));
    setFlights(sorted);
  };

  // Stops filter
  const handleFilterChange = (e) => setStopFilter(e.target.value);

  const filteredFlights = flights.filter((f) => {
    if (stopFilter === "All") return true;
    if (stopFilter === "Non-stop") return f.stops === 0;
    if (stopFilter === "1 Stop") return f.stops === 1;
    if (stopFilter === "2+ Stops") return f.stops >= 2;
    return true;
  });

  const handleBookFlight = (flight) => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    if (!isLoggedIn) {
      // Save the flight the user clicked and show login/signup modal
      setPendingFlight(flight);
      setShowAuthModal(true);
      return;
    }
    navigate("/passenger-details", { state: { flight, searchParams: actualSearchParams } });
  };
  
  return (
    <Container style={{ marginTop: "30px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "30px" }}>
        Flights from {searchParams.from} to {searchParams.to}
      </h2>

      {/* Filters */}
      <div style={{ display: "flex", justifyContent: "center", gap: "20px", flexWrap: "wrap", marginBottom: "20px" }}>
        <Form.Select value={sortBy} onChange={handleSortChange} style={{ width: "200px" }}>
          <option value="">Sort By</option>
          <option value="price-low-high">Price: Low to High</option>
          <option value="price-high-low">Price: High to Low</option>
          <option value="duration">Shortest Duration</option>
          <option value="airline">Airline Name</option>
        </Form.Select>

        <Form.Select value={stopFilter} onChange={handleFilterChange} style={{ width: "200px" }}>
          <option value="All">All Flights</option>
          <option value="Non-stop">Non-stop</option>
          <option value="1 Stop">1 Stop</option>
          <option value="2+ Stops">2+ Stops</option>
        </Form.Select>
      </div>

      {/* Flights List */}
      <Row>
        {filteredFlights.length > 0 ? (
          filteredFlights.map((flight) => (
            <Col md={12} key={flight.id} style={{ marginBottom: "20px" }}>
              <Card style={{ display: "flex", flexDirection: "row", alignItems: "center", padding: "15px", borderRadius: "12px", boxShadow: "0 2px 12px rgba(0,0,0,0.1)" }}>
                
                {/* Left: Flight Details */}
                <div style={{ flex: 3 }}>
                  <h5 style={{ fontWeight: "600" }}>{flight.airline}</h5>
                  <Badge bg={flight.type === "Domestic" ? "success" : "info"} pill>
                    {flight.type}
                  </Badge>
                  <p style={{ marginTop: "5px" }}>
                    Stops: {flight.stops === 0 ? "Non-stop" : `${flight.stops} stop(s)`} <br />
                    Duration: {flight.duration} mins <br />
                    Class: {flight.class}
                  </p>
                </div>

                {/* Middle: Price */}
                <div style={{ flex: 2, textAlign: "center" }}>
                  <h4 style={{ color: "#28a745", fontWeight: "700" }}>₹{flight.price.toLocaleString()}</h4>
                </div>

                {/* Right: Book Now */}
                <div style={{ flex: 1, textAlign: "center" }}>
                  <Button onClick={() => handleBookFlight(flight)} style={{ backgroundColor: "#007bff", border: "none", borderRadius: "8px", padding: "10px 20px" }}>
                    Book Now
                  </Button>
                </div>
              </Card>
            </Col>
          ))
        ) : (
          <p style={{ textAlign: "center", width: "100%" }}>No flights found.</p>
        )}
      </Row>
      <AuthModal
        show={showAuthModal}
        handleClose={() => setShowAuthModal(false)}
        onAuthSuccess={() => {
          setShowAuthModal(false);
          if (pendingFlight) {
            navigate("/passenger-details", { state: { flight: pendingFlight, searchParams: actualSearchParams } });
            setPendingFlight(null);
          }
        }}
      />

    </Container>
  );
};

export default FlightResults;
