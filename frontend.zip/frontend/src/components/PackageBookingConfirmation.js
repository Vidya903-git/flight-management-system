// src/components/PackageBookingConfirmation.js
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Container, Card, Button, Row, Col } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const PackageBookingConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [bookingData, setBookingData] = useState(null);

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    if (!isLoggedIn) {
      navigate("/login");
      return;
    }

    // Get booking data from location state or localStorage
    if (location.state) {
      setBookingData(location.state);
      localStorage.setItem("lastPackageBooking", JSON.stringify(location.state));
    } else {
      // Try to get from localStorage
      const savedBooking = localStorage.getItem("lastPackageBooking");
      if (savedBooking) {
        setBookingData(JSON.parse(savedBooking));
      } else {
        // If no data, redirect to packages page
        navigate("/packages");
      }
    }
  }, [location, navigate]);

  const handleDownloadTicket = () => {
    alert("Package voucher download feature will be available soon!");
  };

  const handlePrintTicket = () => {
    window.print();
  };

  const styles = {
    container: {
      padding: "40px 20px",
      backgroundColor: "#f8f9fa",
      minHeight: "100vh",
    },
    loadingContainer: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundColor: "#f8f9fa",
    },
    successBanner: {
      backgroundColor: "#28a745",
      color: "#fff",
      padding: "30px",
      borderRadius: "12px",
      marginBottom: "30px",
      textAlign: "center",
    },
    successIcon: {
      fontSize: "4rem",
      marginBottom: "15px",
    },
    successTitle: {
      fontSize: "2rem",
      fontWeight: "600",
      marginBottom: "10px",
    },
    successMessage: {
      fontSize: "1.1rem",
      opacity: 0.9,
    },
    bookingId: {
      fontSize: "1.5rem",
      fontWeight: "700",
      backgroundColor: "rgba(255,255,255,0.2)",
      padding: "10px 20px",
      borderRadius: "8px",
      display: "inline-block",
      marginTop: "15px",
    },
    card: {
      border: "none",
      borderRadius: "12px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
      marginBottom: "20px",
    },
    cardHeader: {
      backgroundColor: "#0071eb",
      color: "#fff",
      padding: "15px 20px",
      borderRadius: "12px 12px 0 0",
      fontSize: "1.2rem",
      fontWeight: "600",
    },
    cardBody: {
      padding: "30px",
    },
    sectionTitle: {
      fontSize: "1.3rem",
      fontWeight: "600",
      color: "#333",
      marginBottom: "15px",
      borderBottom: "2px solid #e9ecef",
      paddingBottom: "10px",
    },
    infoRow: {
      display: "flex",
      justifyContent: "space-between",
      padding: "12px 0",
      borderBottom: "1px solid #f0f0f0",
    },
    infoLabel: {
      fontWeight: "500",
      color: "#666",
      fontSize: "0.95rem",
    },
    infoValue: {
      fontWeight: "600",
      color: "#222",
      fontSize: "0.95rem",
    },
    packageImage: {
      width: "100%",
      height: "250px",
      objectFit: "cover",
      borderRadius: "8px",
      marginBottom: "15px",
    },
    actionButtons: {
      display: "flex",
      gap: "15px",
      marginTop: "30px",
      justifyContent: "center",
    },
    button: {
      padding: "12px 30px",
      borderRadius: "8px",
      border: "none",
      fontWeight: "600",
      fontSize: "1rem",
      cursor: "pointer",
      transition: "0.3s",
    },
    downloadButton: {
      backgroundColor: "#0071eb",
      color: "#fff",
    },
    printButton: {
      backgroundColor: "#6c757d",
      color: "#fff",
    },
    homeButton: {
      backgroundColor: "#28a745",
      color: "#fff",
    },
    importantInfo: {
      backgroundColor: "#fff3cd",
      border: "1px solid #ffc107",
      borderRadius: "8px",
      padding: "20px",
      marginTop: "20px",
    },
    importantTitle: {
      fontWeight: "600",
      color: "#856404",
      marginBottom: "10px",
      fontSize: "1.1rem",
    },
    importantText: {
      color: "#856404",
      fontSize: "0.95rem",
      lineHeight: "1.6",
    },
    qrCode: {
      width: "150px",
      height: "150px",
      backgroundColor: "#f0f0f0",
      border: "2px solid #ddd",
      borderRadius: "8px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "20px auto",
      fontSize: "0.9rem",
      color: "#666",
    },
  };

  if (!bookingData) {
    return (
      <div style={styles.loadingContainer}>
        <p>Loading booking confirmation...</p>
      </div>
    );
  }

  const { packageData, formData, paymentMethod, bookingId, bookingDate, pricing } = bookingData;
  const formattedDate = bookingDate ? new Date(bookingDate).toLocaleString() : new Date().toLocaleString();
  const savePackageBooking = () => {
    const booking = {
      type: "package",
      bookingId: bookingId || `PKG${Date.now()}`,
      name: packageData.name,
      location: packageData.location,
      travelDate: formData.travelDate,
      travelers: formData.travelers,
      amount: pricing.finalTotal,
      image: packageData.image,
      bookingDate: formattedDate,
    };
  
    const existing = JSON.parse(localStorage.getItem("packageBookings") || "[]");
    existing.push(booking);
    localStorage.setItem("packageBookings", JSON.stringify(existing));
  
    navigate("/dashboard", {
      state: { page: "bookings" }
    });
  };
  

  return (
    <div style={styles.container}>
      <Container>
        {/* Success Banner */}
        <div style={styles.successBanner}>
          <div style={styles.successIcon}>✅</div>
          <h2 style={styles.successTitle}>Package Booking Confirmed!</h2>
          <p style={styles.successMessage}>
            Your travel package has been successfully booked. A confirmation email with your voucher has been sent to your registered email address.
          </p>
          <div style={styles.bookingId}>
            Booking ID: {bookingId || `PKG${Date.now()}`}
          </div>
        </div>

        <Row>
          {/* Left Column: Booking Details */}
          <Col md={8}>
            {/* Package Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>📦 Package Details</div>
              <div style={styles.cardBody}>
                <img src={packageData.image} alt={packageData.name} style={styles.packageImage} />
                <div style={styles.sectionTitle}>Package Information</div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Package Name:</span>
                  <span style={styles.infoValue}>{packageData.name}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Location:</span>
                  <span style={styles.infoValue}>{packageData.location}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Duration:</span>
                  <span style={styles.infoValue}>{packageData.duration}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Travel Date:</span>
                  <span style={styles.infoValue}>{formData.travelDate}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Number of Travelers:</span>
                  <span style={styles.infoValue}>{formData.travelers}</span>
                </div>
              </div>
            </Card>

            {/* Traveler Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>👤 Traveler Details</div>
              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Primary Traveler Information</div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Name:</span>
                  <span style={styles.infoValue}>{formData.passengerName}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Age:</span>
                  <span style={styles.infoValue}>{formData.age} years</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Gender:</span>
                  <span style={styles.infoValue}>{formData.gender}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Mobile:</span>
                  <span style={styles.infoValue}>{formData.mobile || "N/A"}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Email:</span>
                  <span style={styles.infoValue}>{formData.email || "N/A"}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>ID Proof:</span>
                  <span style={styles.infoValue}>
                    {formData.idProofType} - {formData.idProofNumber}
                  </span>
                </div>
              </div>
            </Card>

            {/* Payment Details */}
            <Card style={styles.card}>
              <div style={styles.cardHeader}>💳 Payment Details</div>
              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Payment Information</div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Payment Method:</span>
                  <span style={styles.infoValue}>
                    {paymentMethod === "card" ? "Credit/Debit Card" :
                     paymentMethod === "upi" ? "UPI" :
                     paymentMethod === "wallet" ? "Digital Wallet" : paymentMethod}
                  </span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Base Price:</span>
                  <span style={styles.infoValue}>₹{pricing.totalPrice.toLocaleString()}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Taxes & Fees:</span>
                  <span style={styles.infoValue}>₹{pricing.taxes.toLocaleString()}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Service Charge:</span>
                  <span style={styles.infoValue}>₹{pricing.serviceCharge.toLocaleString()}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Total Amount Paid:</span>
                  <span style={{ ...styles.infoValue, color: "#28a745", fontSize: "1.2rem" }}>
                    ₹{pricing.finalTotal.toLocaleString()}
                  </span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Payment Status:</span>
                  <span style={{ ...styles.infoValue, color: "#28a745" }}>✅ Paid</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Booking Date & Time:</span>
                  <span style={styles.infoValue}>{formattedDate}</span>
                </div>
              </div>
            </Card>

            {/* Important Information */}
            <div style={styles.importantInfo}>
              <div style={styles.importantTitle}>📋 Important Information</div>
              <div style={styles.importantText}>
                <p><strong>• Voucher:</strong> Your travel voucher will be sent to your email. Please carry a printed or digital copy during your trip.</p>
                <p><strong>• Check-in:</strong> Please arrive at the hotel/accommodation as per the check-in time mentioned in your voucher.</p>
                <p><strong>• Required Documents:</strong> Please carry a valid ID proof (as provided during booking) and your booking confirmation.</p>
                <p><strong>• Cancellation:</strong> Cancellation and refund policies vary by package. Please check the terms and conditions.</p>
                <p><strong>• Contact:</strong> For any queries, contact our customer support at support@wanderway.com or call +91-1800-XXX-XXXX.</p>
              </div>
            </div>
          </Col>

          {/* Right Column: Booking Summary & QR Code */}
          <Col md={4}>
            <Card style={styles.card}>
              <div style={styles.cardHeader}>📄 Booking Summary</div>
              <Button
                onClick={savePackageBooking}
                style={{ ...styles.button, backgroundColor: "#007bff", color: "#fff",marginTop: "10px"}}
              >
                📘 View in My Bookings
              </Button>

              <div style={styles.cardBody}>
                <div style={styles.sectionTitle}>Quick Reference</div>
                
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Booking ID:</span>
                  <span style={styles.infoValue}>{bookingId || `PKG${Date.now()}`}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Traveler:</span>
                  <span style={styles.infoValue}>{formData.passengerName}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Package:</span>
                  <span style={styles.infoValue}>{packageData.name}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Travel Date:</span>
                  <span style={styles.infoValue}>{formData.travelDate}</span>
                </div>
                <div style={styles.infoRow}>
                  <span style={styles.infoLabel}>Total Amount:</span>
                  <span style={{ ...styles.infoValue, color: "#28a745", fontSize: "1.1rem" }}>
                    ₹{pricing.finalTotal.toLocaleString()}
                  </span>
                </div>

                {/* QR Code Placeholder */}
                <div style={styles.qrCode}>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: "2rem", marginBottom: "5px" }}>📱</div>
                    <div>QR Code</div>
                    <div style={{ fontSize: "0.8rem", marginTop: "5px" }}>
                      {bookingId || `PKG${Date.now()}`}
                    </div>
                  </div>
                </div>
                <p style={{ textAlign: "center", fontSize: "0.85rem", color: "#666", marginTop: "10px" }}>
                  Show this QR code for quick check-in
                </p>
              </div>
            </Card>

            {/* Action Buttons */}
            <div style={styles.actionButtons}>
              <Button
                onClick={handleDownloadTicket}
                style={{ ...styles.button, ...styles.downloadButton }}
              >
                📥 Download Voucher
              </Button>
            </div>
            <div style={styles.actionButtons}>
              <Button
                onClick={handlePrintTicket}
                style={{ ...styles.button, ...styles.printButton }}
              >
                🖨️ Print Voucher
              </Button>
            </div>
            <div style={styles.actionButtons}>
              <Button
                onClick={() => navigate("/packages")}
                style={{ ...styles.button, ...styles.homeButton }}
              >
                🏠 Back to Packages
              </Button>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default PackageBookingConfirmation;

