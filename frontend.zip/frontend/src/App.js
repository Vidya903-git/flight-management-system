// src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Navbar from "./components/Navbar";
import Home from "./components/Home.js";
import Travel from "./components/Travel.js";
import MapView from "./components/Mapview.js";
import FlightResults from "./components/FlightResults.js";
import PassengerDetails from "./components/PassengerDetails.js";
import Booking from "./components/Booking.js";
import BookingConfirmation from "./components/BookingConfirmation.js";
import Packages from "./components/Packages.js";
import PackageDetails from "./components/PackageDetails.js";
import PackageBooking from "./components/PackageBooking.js";
import PackageBookingConfirmation from "./components/PackageBookingConfirmation.js";
import Dashboard from "./components/dashboard.js";
import SeatFoodSelection from "./components/SeatFoodSelection.js";
import About from "./components/About.js";
import Contact from "./components/Contact.js";

function App() {
  return (
    <Router>
      {/* Global Header with AuthModal integrated */}
      <Header />
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/travel" element={<Travel />} />
        <Route path="/packages" element={<Packages />} />
        <Route path="/package-details" element={<PackageDetails />} />
        <Route path="/package-booking" element={<PackageBooking />} />
        <Route
          path="/package-booking-confirmation"
          element={<PackageBookingConfirmation />}
        />
        <Route path="/mapview" element={<MapView />} />
        <Route path="/flights" element={<FlightResults />} />
        <Route path="/passenger-details" element={<PassengerDetails />} />
        <Route path="/booking" element={<Booking />} />
        <Route
          path="/booking-confirmation"
          element={<BookingConfirmation />}
        />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/seat-food" element={<SeatFoodSelection />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;
